package com.example.assignment2.services;

import com.example.assignment2.model.Trainer;

import java.util.List;

public interface TrainerServiceInterface {

    public void insertTrainer(Trainer t);

    public void deleteTrainer(Trainer t);

    public List<Trainer> getAllTrainers();

    public Trainer getById(Integer id);
}

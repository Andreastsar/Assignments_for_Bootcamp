package com.example.assignment2.controllers;

import com.example.assignment2.model.Trainer;
import com.example.assignment2.services.TrainerServiceInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/trainers")
public class TrainerController {

    @Autowired
    TrainerServiceInterface trainerService;

    @GetMapping("/showList")
    public String showAllTrainers(Model model) {
        List<Trainer> allTrainers = trainerService.getAllTrainers();
        model.addAttribute("allTrainers", allTrainers);
        return "trainersList";
    }

    @GetMapping("/showFormForAdd")
    public String showFormForAdd(Model model) {
        Trainer trainer = new Trainer();
        model.addAttribute("trainer", trainer);
        return "trainer-form";
    }

    @PostMapping("/saveTrainer")
    public String saveTrainer(@ModelAttribute("trainer") Trainer trainer) {
        trainerService.insertTrainer(trainer);
        return "redirect:/trainers/showList";
    }

    @GetMapping("/showFormForUpdate")
    public String showFormForUpdate(@RequestParam("trainerId") Integer id, Model model) {
        // Get the Trainer from DB
        Trainer insertedTrainer = trainerService.getById(id);
        // Set trainer as a model attribute to pre-populate the update form
        model.addAttribute("trainer", insertedTrainer);
        return "trainer-form";
    }

    @GetMapping("/delete")
    public String deleteTrainer(@RequestParam("trainerId") Integer id) {
        Trainer toBeDeleted = trainerService.getById(id);
        trainerService.deleteTrainer(toBeDeleted);
        return "redirect:/trainers/showList";
    }
}

package com.example.assignment2.services;

import com.example.assignment2.model.Trainer;
import com.example.assignment2.repositories.TrainerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TrainerService implements TrainerServiceInterface {

    @Autowired
    TrainerRepository trainerRepository;

    @Override
    public void insertTrainer(Trainer t) {
        trainerRepository.save(t);
    }

    @Override
    public void deleteTrainer(Trainer t) {
        trainerRepository.delete(t);
    }

    @Override
    public List<Trainer> getAllTrainers() {
        return trainerRepository.findAll();
    }

    @Override
    public Trainer getById(Integer id) {
        return trainerRepository.findById(id).get();
    }
}

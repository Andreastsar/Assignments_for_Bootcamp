This is the assignment2 for the Java Coding Bootcamp

Spring MVC CRUD example for Create,Read,Update,Delete a Trainer via form.
 
Using Spring Boot DevTools /
		Spring Web /
		Spring Data JPA /
		mySQL Driver /
		mySQL DataBase.
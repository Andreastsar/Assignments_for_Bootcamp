This is the first assignment for the Java coding bootcamp.

info about the assignment1:

Page Students---> Add + Edit Form with CSS(bootstrap 4) and validation for First Name, Last Name, Tuition Fees. / Edit Form--> Pre-selected First Name, Last Name, Date of Birth, Tuition Fees.

Page Trainers---> Add + Edit Form with CSS(bootstrap 4) and validation for First Name, Last Name, Subject / Edit Form--> Pre-selected First Name, Last Name, Subject.

Page Courses---> Add + Edit Form with CSS(bootstrap 4) and validation for Stream, Course Type / Edit Form--> Pre-selected Stream , Course Type, Start_End Dates.

Page Assignments--->Add + Edit Form with CSS(bootstrap 4) and validation for Title, Description, Oral_Total Mark / Edit form--> Pre-selected Title, Description, Date, Oral_Total Mark.

Page Assignments/Course--->Add + Edit Form with CSS(bootstrap 4) and validation for Course, Assignment, Oral Mark (1-30), Total Mark(1-70) / Edit Form--> Pre-selected Course, Oral Mark, Total Mark, Date of Submission.
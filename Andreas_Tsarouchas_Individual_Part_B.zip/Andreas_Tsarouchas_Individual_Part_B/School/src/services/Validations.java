package services;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Date;
import java.util.Scanner;

public class Validations {

    // Validation for Integer in Range[x,y]
    public static int integerValidationInRange(Scanner sc, int x, int y) {
        boolean isValid = false;
        int choice = 0;
        System.out.println("Enter integer: ");
        while (!isValid) {
            if (sc.hasNextInt()) {
                choice = sc.nextInt();
                if (choice >= x && choice <= y) {
                    isValid = true;
                } else {
                    System.out.println("Choose an integer between " + x + " - " + y + ": ");
                }
            } else {
                System.out.println("Invalid entry. Please use an integer!");
                System.out.println("Enter integer:");
                sc.next();
            }
        }
        return choice;
    }

    // Validation for Double in Range[x,y]
    public static double doubleValidationInRange(Scanner sc, double x, double y) {
        boolean isValid = false;
        double choice = 0;
        System.out.println("Enter decimal number: ");
        while (!isValid) {
            if (sc.hasNextDouble()) {
                choice = sc.nextDouble();
                if (choice >= x && choice <= y) {
                    isValid = true;
                } else {
                    System.out.println("Choose a decimal number between " + x + " - " + y + ": ");
                }
            } else {
                System.out.println("Invalid entry. Please use a decimal number!");
                System.out.println("Enter decimal number:");
                sc.next();
            }
        }
        return choice;
    }

    // Validation for Strings for Names (only characters allowed)
    public static String stringValidationForName(Scanner sc) {
        boolean isValid = false;
        String result = null;
        System.out.println("Enter your Name: ");
        while (!isValid) {
            if (sc.hasNextLine()) {
                result = sc.nextLine().trim();
                if (result.matches("^[a-zA-Z]+$")) {
                    isValid = true;
                } else {
                    System.out.println("Name should contain only characters!");
                }
            } else {
                System.out.println("Invalid entry. Please enter a Name: ");
                System.out.println("Enter your Name: ");
                sc.next();
            }
        }
        return result;
    }

    private static final DateTimeFormatter PARSE_FORMATTER
            = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public static Date insertDate(Scanner sc) {
        System.out.println("Please enter a date (yyyy-MM-dd)");
        sc.next();
        String uDate = sc.nextLine();
        Date d1 = null;
        try {
            LocalDate.parse(uDate, PARSE_FORMATTER);
            System.out.println(uDate + " is a valid Date");
            d1 = new SimpleDateFormat("yyyy-MM-dd").parse(uDate);
        } catch (
                DateTimeParseException dtpe) {
            System.out.println(uDate + " is a not valid Date");
        } catch (ParseException e) {
            throw new RuntimeException(e);
        } finally {
            return d1;
        }
    }
}
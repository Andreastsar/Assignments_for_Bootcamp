package services;

import dao.*;

public class PrintData {

    public static void printAllData() {
        // Output for all Students
        StudentDao.printAllStudents();

        // Output for all Trainers
        TrainerDao.printAllTrainers();

        // Output for all Assignments
        AssignmentDao.printAllAssignments();

        // Output for all Courses
        CourseDao.printAllCourses();

        // Output for all Students / Course
        SchoolDao.printAllStudentsPerCourse();

        // Output for all Trainers / Course
        SchoolDao.printAllTrainersPerCourse();

        // Output for all Assignments / Course
        SchoolDao.printAllAssignmentsPerCourse();

        // Output for all Assignments / Course / Student
        SchoolDao.printAllAssignmentsPerCoursePerStudent();

        // Output for all Students that belong to more than one courses
        StudentDao.printAllStudentsBelongToMoreThanOneCourse();
    }
}

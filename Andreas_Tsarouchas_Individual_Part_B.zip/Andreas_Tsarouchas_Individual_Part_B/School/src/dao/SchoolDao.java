package dao;

import Model.*;
import utilities.DBUtilities;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SchoolDao {

    // Methods about Students------------------------------------------------------------
    public static List<StudentPerCourse> getAllStudentsPerCourse() {
        Connection con = DBUtilities.getConnection();
        List<StudentPerCourse> spc = new ArrayList<>();
        String sql = "select *\n" +
                "from student\n" +
                "join studentcourse on stu_ssn = student\n" +
                "join course on Course_ID = CourseForStudent\n" +
                "order by Course_ID;";
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                StudentPerCourse o = new StudentPerCourse(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getDate(4), rs.getDouble(5), rs.getInt(6),
                        rs.getInt(7), rs.getInt(8), rs.getString(9), rs.getString(10), rs.getString(11), rs.getDate(12), rs.getDate(13));
                spc.add(o);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return spc;
    }

    public static void printAllStudentsPerCourse() {
        System.out.println("*** ALL STUDENTS PER COURSE ***");
        for (StudentPerCourse element : SchoolDao.getAllStudentsPerCourse()) {
            System.out.println(element);
        }
        // or System.out.println(SchoolDao.getAllStudentsPerCourse()); --> 1 row
        System.out.println("------------------------------------------------------------------");
    }
    // -----------------------------------------------------------------------------------------------

    // Methods about Trainers
    public static List<TrainerPerCourse> getAllTrainersPerCourse() {
        Connection con = DBUtilities.getConnection();
        List<TrainerPerCourse> tpc = new ArrayList<>();
        String sql = "select *\n" +
                "from trainer\n" +
                "join trainercourse on trainer = Tr_SSN\n" +
                "join course on Course_ID = CourseForTrainer\n" +
                "order by Course_ID;";
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                TrainerPerCourse o = new TrainerPerCourse(rs.getInt(1),rs.getString(2), rs.getString(3),rs.getDate(4),rs.getInt(5),
                        rs.getInt(6),rs.getInt(7),rs.getString(8),rs.getString(9),rs.getString(10),rs.getDate(11),rs.getDate(12));
                tpc.add(o);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return tpc;
    }

    public static void printAllTrainersPerCourse() {
        System.out.println("*** ALL TRAINERS PER COURSE ***");
        for (TrainerPerCourse element : SchoolDao.getAllTrainersPerCourse()) {
            System.out.println(element);
        }
        // or System.out.println(SchoolDao.getAllTrainersPerCourse()); --> 1 row
        System.out.println("------------------------------------------------------------------");
    }

    // Methods about Assignments

    public static List<AssignmentPerCourse> getAllAssignmentsPerCourse() {
        Connection con = DBUtilities.getConnection();
        List<AssignmentPerCourse> apc = new ArrayList<>();
        String sql = "select *\n" +
                "from assignment\n" +
                "join assignmentcourse on assignment = Ass_id\n" +
                "join course on course_id = courseforassignment\n" +
                "order by course_id;";
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                AssignmentPerCourse o = new AssignmentPerCourse(rs.getInt(1),rs.getString(2),rs.getDate(3),rs.getDouble(4),rs.getDouble(5),rs.getInt(6),
                        rs.getInt(7),rs.getInt(8),rs.getString(9),rs.getString(10),rs.getString(11),rs.getDate(12),rs.getDate(13));
                apc.add(o);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return apc;
    }

    public static void printAllAssignmentsPerCourse() {
        System.out.println("*** ALL ASSIGNMENTS PER COURSE ***");
        for (AssignmentPerCourse element : SchoolDao.getAllAssignmentsPerCourse()) {
            System.out.println(element);
        }
        // or System.out.println(SchoolDao.getAllAssignmentsPerCourse()); --> 1 row
        System.out.println("------------------------------------------------------------------");
    }

    //-----------------------

    public static List<AssignmentPerCoursePerStudent> getAllAssignmentsPerCoursePerStudent() {
        Connection con = DBUtilities.getConnection();
        List<AssignmentPerCoursePerStudent> apcps = new ArrayList<>();
        String sql = "select *\n" +
                "from assignment\n" +
                "join assignmentcourse  on ass_id = assignment\n" +
                "join course on courseforassignment = course_id\n" +
                "join studentcourse on course_id = courseforstudent\n" +
                "join student on stu_ssn = student\n" +
                "order by stu_ssn;";
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                AssignmentPerCoursePerStudent o = new AssignmentPerCoursePerStudent(rs.getInt(1),rs.getString(2),rs.getDate(3),rs.getDouble(4),rs.getDouble(5),rs.getInt(6),rs.getInt(7),
                        rs.getInt(8),rs.getString(9),rs.getString(10),rs.getString(11),rs.getDate(12),rs.getDate(13),rs.getInt(14),rs.getInt(15),
                        rs.getInt(16),rs.getString(17),rs.getString(18),rs.getDate(19),rs.getDouble(20));
                apcps.add(o);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return apcps;
    }

    public static void printAllAssignmentsPerCoursePerStudent() {
        System.out.println("*** ALL ASSIGNMENTS PER COURSE PER STUDENT ***");
        for (AssignmentPerCoursePerStudent element : SchoolDao.getAllAssignmentsPerCoursePerStudent()) {
            System.out.println(element);
        }
        // or System.out.println(SchoolDao.getAllAssignmentsPerCoursePerStudent()); --> 1 row
        System.out.println("------------------------------------------------------------------");
    }

    // ----------------------------------------------------------------------------------------------------------

}

package dao;

import Model.Student;
import Model.Trainer;
import services.Validations;
import utilities.DBUtilities;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TrainerDao {

    public static List<Trainer> getAllTrainers(){
        Connection con = DBUtilities.getConnection();
        List<Trainer> trainers = new ArrayList<>();
        String sql = "select * from trainer";
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                Trainer t = new Trainer(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getDate(4));
                trainers.add(t);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return trainers;
    }

    public static void printAllTrainers(){
        System.out.println("*** ALL TRAINERS ***");
        for (Trainer element : TrainerDao.getAllTrainers()) {
            System.out.println(element);
        }
        // or System.out.println(TrainerDao.getAllTrainers()); --> 1 row
        System.out.println("------------------------------------------------------------------");
    }

    // Insert a new Student in DB
    public static void insertTrainerToDB(Trainer t) {
        Connection con = DBUtilities.getConnection();
        String insertTrainer = "insert into trainer values(?,?,?,?)";
        try {
            PreparedStatement ps = con.prepareStatement(insertTrainer);
            ps.setInt(1,t.getTr_SSN());
            ps.setString(2,t.getTr_Fname());
            ps.setString(3,t.getTr_Lname());
            ps.setDate(4, (Date) t.getTr_DOB());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static Trainer createTrainer(Scanner sc) {
        System.out.println("---FIRST NAME---");
        String fname = Validations.stringValidationForName(sc);
        System.out.println("---LAST NAME---");
        String lname = Validations.stringValidationForName(sc);
        System.out.println("---ENTER ID (1000000-5999999)");
        int id = Validations.integerValidationInRange(sc, 1000000, 5999999);
        System.out.println("---DATE OF BIRTH---");
        java.util.Date date = Validations.insertDate(sc);
        Trainer newTrainer = new Trainer(id, fname, lname, date);
        return newTrainer;
    }
}

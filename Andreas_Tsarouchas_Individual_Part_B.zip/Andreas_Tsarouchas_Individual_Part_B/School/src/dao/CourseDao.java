package dao;

import Model.Assignment;
import Model.Course;
import services.Validations;
import utilities.DBUtilities;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CourseDao {

    public static List<Course> getAllCourses(){
        Connection con = DBUtilities.getConnection();
        List<Course> courses = new ArrayList<>();
        String sql = "select * from course";
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                Course c = new Course(rs.getInt(1),rs.getString(2),
                        rs. getString(3),rs.getString(4),rs.getDate(5),rs.getDate(6));
                courses.add(c);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return courses;
    }

    public static void printAllCourses() {
        System.out.println("*** ALL COURSES ***");
        for (Course element : CourseDao.getAllCourses()) {
            System.out.println(element);
        }
        // or System.out.println(CourseDao.getAllCourses()); --> 1 row
        System.out.println("------------------------------------------------------------------");
    }

    // Insert a new Course in DB
    public static void insertCourseToDB(Course c) {
        Connection con = DBUtilities.getConnection();
        String insertCourse = "insert into course values(?,?,?,?,?,?)";
        try {
            PreparedStatement ps = con.prepareStatement(insertCourse);
            ps.setInt(1,c.getCourse_ID());
            ps.setString(2,c.getCou_Title());
            ps.setString(3,c.getType());
            ps.setString(4,c.getStream());
            ps.setDate(5, (Date) c.getStart_Date());
            ps.setDate(6, (Date) c.getEnd_Date());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static Course createCourse(Scanner sc) {
        System.out.println("---TITLE---");
        String title = Validations.stringValidationForName(sc);
        System.out.println("---TYPE (Full-time,Part-time)---");
        String type = Validations.stringValidationForName(sc);
        System.out.println("---STREAM (Java,Ruby,Python,C#,CSS,JavaScript,HTML)---");
        String stream = Validations.stringValidationForName(sc);
        System.out.println("---ENTER ID (15-100)");
        int id = Validations.integerValidationInRange(sc, 15, 100);
        System.out.println("---START DATE---");
        Date sdate = (Date) Validations.insertDate(sc);
        System.out.println("---END DATE---");
        Date edate = (Date) Validations.insertDate(sc);
        Course c = new Course(id,title,type,stream,sdate,edate);
        return c;
    }
}

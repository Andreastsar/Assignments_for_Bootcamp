package dao;

import Model.Assignment;
import Model.Student;
import services.Validations;
import utilities.DBUtilities;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class AssignmentDao {

    public static List<Assignment> getAllAssignments(){
        Connection con = DBUtilities.getConnection();
        List<Assignment> assignments = new ArrayList<>();
        String sql = "select * from assignment";
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Assignment a = new Assignment(rs.getInt(1),rs.getString(2),rs.getDate(3),rs.getDouble(4),rs.getDouble(5));
                assignments.add(a);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return assignments;
    }

    public static void printAllAssignments(){
        System.out.println("*** ALL ASSIGNMENTS ***");
        for (Assignment element : AssignmentDao.getAllAssignments()) {
            System.out.println(element);
        }
        // or System.out.println(AssignmentDao.getAllAssignments()); --> 1 row
        System.out.println("------------------------------------------------------------------");
    }

    // Insert a new Assignment in DB
    public static void insertAssignmentToDB(Assignment a) {
        Connection con = DBUtilities.getConnection();
        String insertAssignment = "insert into assignment values(?,?,?,?,?)";
        try {
            PreparedStatement ps = con.prepareStatement(insertAssignment);
            ps.setInt(1,a.getAss_Date());
            ps.setString(2,a.getAss_Title());
            ps.setDate(3, (Date) a.getSub_Date());
            ps.setDouble(4,a.getOral_Mark());
            ps.setDouble(5,a.getTotal_Mark());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static Assignment createAssignment(Scanner sc) {
        System.out.println("---TITLE---");
        String title = Validations.stringValidationForName(sc);
        System.out.println("---ORAL MARK (0-30)---");
        double omark = Validations.doubleValidationInRange(sc,0,30);
        System.out.println("---ENTER ID (11-100)");
        int id = Validations.integerValidationInRange(sc, 11, 100);
        System.out.println("---DATE OF SUBMIT---");
        java.util.Date date = Validations.insertDate(sc);
        System.out.println("---TOTAL MARK (0-70)---");
        double tmark = Validations.doubleValidationInRange(sc, 0, 70);
        Assignment a = new Assignment(id,title,date,omark,tmark);
        return a;
    }
}

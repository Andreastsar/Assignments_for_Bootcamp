package dao;

import Model.Student;
import Model.StudentByID;
import services.Validations;
import utilities.DBUtilities;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class StudentDao {

    public static List<Student> getAllStudents(){
        Connection con = DBUtilities.getConnection();
        List<Student> students = new ArrayList<>();
        String sql = "select * from student";
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
             ps = con.prepareStatement(sql);
             rs = ps.executeQuery();
             while (rs.next()) {
                 Student s = new Student(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getDate(4),rs.getDouble(5));
                 students.add(s);
             }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return students;
    }

    public static void printAllStudents() {
        System.out.println("*** ALL STUDENTS ***");
        for (Student element : StudentDao.getAllStudents()) {
            System.out.println(element);
        }
        // OR
        // System.out.println(StudentDao.getAllStudents()); --> 1 row
        System.out.println("------------------------------------------------------------------");
    }

    // ----------------------------------------------------------------------------------------------------------

    public static List<StudentByID> getAllStudentsBelongToMoreThanOneCourse() {
        Connection con = DBUtilities.getConnection();
        List<StudentByID> studentsID = new ArrayList<>();
        String sql = "select student\n" +
                "from studentcourse\n" +
                "group by CourseForStudent\n" +
                "having count(CourseForStudent) > ?;";
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1,1);
            rs = ps.executeQuery();
            while (rs.next()) {
                StudentByID o = new StudentByID(rs.getInt(1));
                studentsID.add(o);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return studentsID;
    }

    public static void printAllStudentsBelongToMoreThanOneCourse() {
        System.out.println("*** ALL STUDENTS BELONG TO MORE THAN ONE COURSE ***");
        for (StudentByID element : StudentDao.getAllStudentsBelongToMoreThanOneCourse()) {
            System.out.println(element);
        }
        // OR
        // System.out.println(StudentDao.getAllStudentsBelongToMoreThanOneCourse()); --> 1 row
        System.out.println("------------------------------------------------------------------");
    }

    // Insert a new Student in DB
    public static void insertStudentToDB(Student s) {
        Connection con = DBUtilities.getConnection();
        String insertStudent = "insert into student values(?,?,?,?,?)";
        try {
            PreparedStatement ps = con.prepareStatement(insertStudent);
            ps.setInt(1,s.getStu_SSN());
            ps.setString(2,s.getStu_Fname());
            ps.setString(3,s.getStu_Lname());
            ps.setDate(4, (Date) s.getStu_DOB());
            ps.setDouble(5,s.getTuition_Fees());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static Student createStudent(Scanner sc) {
        System.out.println("---FIRST NAME---");
        String fname = Validations.stringValidationForName(sc);
        System.out.println("---LAST NAME---");
        String lname = Validations.stringValidationForName(sc);
        System.out.println("---ENTER ID (6000000-9999999)");
        int id = Validations.integerValidationInRange(sc, 6000000, 9999999);
        System.out.println("---DATE OF BIRTH---");
        java.util.Date date = Validations.insertDate(sc);
        System.out.println("---TUITION FEES---");
        double tuitionFees = Validations.doubleValidationInRange(sc, 0, 10000);
        Student newStudent = new Student(id, fname, lname, date, tuitionFees);
        return newStudent;
    }
}

package Model;

public class StudentByID {
    private int stu_ID;

    public StudentByID(int stu_ID) {
        this.stu_ID = stu_ID;
    }

    public int getStu_ID() {
        return stu_ID;
    }

    public void setStu_ID(int stu_ID) {
        this.stu_ID = stu_ID;
    }

    @Override
    public String toString() {
        return "StudentByID{" +
                "stu_ID=" + stu_ID +
                '}';
    }
}

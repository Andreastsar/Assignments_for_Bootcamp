package Model;

import java.time.LocalDate;
import java.util.Date;

public class Student {
    private int stu_SSN;
    private String stu_Fname;
    private String stu_Lname;
    private Date stu_DOB;
    private double tuition_Fees;

    @Override
    public String toString() {
        return "Student{" +
                "stu_SSN=" + stu_SSN +
                ", stu_Fname='" + stu_Fname + '\'' +
                ", stu_Lname='" + stu_Lname + '\'' +
                ", stu_DOB=" + stu_DOB +
                ", tuition_Fees=" + tuition_Fees +
                '}';
    }

    public Student(int stu_SSN, String stu_Fname, String stu_Lname, Date stu_DOB, double tuition_Fees) {
        this.stu_SSN = stu_SSN;
        this.stu_Fname = stu_Fname;
        this.stu_Lname = stu_Lname;
        this.stu_DOB = stu_DOB;
        this.tuition_Fees = tuition_Fees;
    }

    public int getStu_SSN() {
        return stu_SSN;
    }

    public void setStu_SSN(int stu_SSN) {
        this.stu_SSN = stu_SSN;
    }

    public String getStu_Fname() {
        return stu_Fname;
    }

    public void setStu_Fname(String stu_Fname) {
        this.stu_Fname = stu_Fname;
    }

    public String getStu_Lname() {
        return stu_Lname;
    }

    public void setStu_Lname(String stu_Lname) {
        this.stu_Lname = stu_Lname;
    }

    public Date getStu_DOB() {
        return stu_DOB;
    }

    public void setStu_DOB(Date stu_DOB) {
        this.stu_DOB = stu_DOB;
    }

    public double getTuition_Fees() {
        return tuition_Fees;
    }

    public void setTuition_Fees(double tuition_Fees) {
        this.tuition_Fees = tuition_Fees;
    }
}

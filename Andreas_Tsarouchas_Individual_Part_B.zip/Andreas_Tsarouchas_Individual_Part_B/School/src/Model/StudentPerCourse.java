package Model;

import java.util.Date;

public class StudentPerCourse {
    private int stu_SSN;
    private String stu_Fname;
    private String stu_Lname;
    private Date stu_DOB;
    private double tuition_Fees;
    private int student;
    private int courseForStudent;
    private int course_ID;
    private String cou_Title;
    private String type;
    private String stream;
    private Date start_Date;
    private Date end_Date;

    @Override
    public String toString() {
        return "StudentPerCourse{" +
                "stu_SSN=" + stu_SSN +
                ", stu_Fname='" + stu_Fname + '\'' +
                ", stu_Lname='" + stu_Lname + '\'' +
                ", stu_DOB=" + stu_DOB +
                ", tuition_Fees=" + tuition_Fees +
                ", student=" + student +
                ", courseForStudent=" + courseForStudent +
                ", course_ID=" + course_ID +
                ", cou_Title='" + cou_Title + '\'' +
                ", type='" + type + '\'' +
                ", stream='" + stream + '\'' +
                ", start_Date=" + start_Date +
                ", end_Date=" + end_Date +
                '}';
    }

    public StudentPerCourse(int stu_SSN, String stu_Fname, String stu_Lname, Date stu_DOB, double tuition_Fees, int student, int courseForStudent, int course_ID, String cou_Title, String type, String stream, Date start_Date, Date end_Date) {
        this.stu_SSN = stu_SSN;
        this.stu_Fname = stu_Fname;
        this.stu_Lname = stu_Lname;
        this.stu_DOB = stu_DOB;
        this.tuition_Fees = tuition_Fees;
        this.student = student;
        this.courseForStudent = courseForStudent;
        this.course_ID = course_ID;
        this.cou_Title = cou_Title;
        this.type = type;
        this.stream = stream;
        this.start_Date = start_Date;
        this.end_Date = end_Date;
    }

    public int getStu_SSN() {
        return stu_SSN;
    }

    public void setStu_SSN(int stu_SSN) {
        this.stu_SSN = stu_SSN;
    }

    public String getStu_Fname() {
        return stu_Fname;
    }

    public void setStu_Fname(String stu_Fname) {
        this.stu_Fname = stu_Fname;
    }

    public String getStu_Lname() {
        return stu_Lname;
    }

    public void setStu_Lname(String stu_Lname) {
        this.stu_Lname = stu_Lname;
    }

    public Date getStu_DOB() {
        return stu_DOB;
    }

    public void setStu_DOB(Date stu_DOB) {
        this.stu_DOB = stu_DOB;
    }

    public double getTuition_Fees() {
        return tuition_Fees;
    }

    public void setTuition_Fees(double tuition_Fees) {
        this.tuition_Fees = tuition_Fees;
    }

    public int getStudent() {
        return student;
    }

    public void setStudent(int student) {
        this.student = student;
    }

    public int getCourseForStudent() {
        return courseForStudent;
    }

    public void setCourseForStudent(int courseForStudent) {
        this.courseForStudent = courseForStudent;
    }

    public int getCourse_ID() {
        return course_ID;
    }

    public void setCourse_ID(int course_ID) {
        this.course_ID = course_ID;
    }

    public String getCou_Title() {
        return cou_Title;
    }

    public void setCou_Title(String cou_Title) {
        this.cou_Title = cou_Title;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getStream() {
        return stream;
    }

    public void setStream(String stream) {
        this.stream = stream;
    }

    public Date getStart_Date() {
        return start_Date;
    }

    public void setStart_Date(Date start_Date) {
        this.start_Date = start_Date;
    }

    public Date getEnd_Date() {
        return end_Date;
    }

    public void setEnd_Date(Date end_Date) {
        this.end_Date = end_Date;
    }
}

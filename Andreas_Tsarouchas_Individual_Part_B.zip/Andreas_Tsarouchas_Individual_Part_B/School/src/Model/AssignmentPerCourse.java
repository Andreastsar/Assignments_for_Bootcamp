package Model;

import java.util.Date;

public class AssignmentPerCourse {
    private int ass_ID;
    private String ass_Title;
    private Date sub_Date;
    private double oral_Mark;
    private double total_Mark;
    private int assignment;
    private int courseForAssignment;
    private int course_ID;
    private String cou_Title;
    private String type;
    private String stream;
    private Date start_Date;
    private Date end_Date;

    public AssignmentPerCourse(int ass_ID, String ass_Title, Date sub_Date, double oral_Mark, double total_Mark, int assignment, int courseForAssignment, int course_ID, String cou_Title, String type, String stream, Date start_Date, Date end_Date) {
        this.ass_ID = ass_ID;
        this.ass_Title = ass_Title;
        this.sub_Date = sub_Date;
        this.oral_Mark = oral_Mark;
        this.total_Mark = total_Mark;
        this.assignment = assignment;
        this.courseForAssignment = courseForAssignment;
        this.course_ID = course_ID;
        this.cou_Title = cou_Title;
        this.type = type;
        this.stream = stream;
        this.start_Date = start_Date;
        this.end_Date = end_Date;
    }

    @Override
    public String toString() {
        return "AssignmentPerCourse{" +
                "ass_ID=" + ass_ID +
                ", ass_Title='" + ass_Title + '\'' +
                ", sub_Date=" + sub_Date +
                ", oral_Mark=" + oral_Mark +
                ", total_Mark=" + total_Mark +
                ", assignment=" + assignment +
                ", courseForAssignment=" + courseForAssignment +
                ", course_ID=" + course_ID +
                ", cou_Title='" + cou_Title + '\'' +
                ", type='" + type + '\'' +
                ", stream='" + stream + '\'' +
                ", start_Date=" + start_Date +
                ", end_Date=" + end_Date +
                '}';
    }

    public int getAss_ID() {
        return ass_ID;
    }

    public void setAss_ID(int ass_ID) {
        this.ass_ID = ass_ID;
    }

    public String getAss_Title() {
        return ass_Title;
    }

    public void setAss_Title(String ass_Title) {
        this.ass_Title = ass_Title;
    }

    public Date getSub_Date() {
        return sub_Date;
    }

    public void setSub_Date(Date sub_Date) {
        this.sub_Date = sub_Date;
    }

    public double getOral_Mark() {
        return oral_Mark;
    }

    public void setOral_Mark(double oral_Mark) {
        this.oral_Mark = oral_Mark;
    }

    public double getTotal_Mark() {
        return total_Mark;
    }

    public void setTotal_Mark(double total_Mark) {
        this.total_Mark = total_Mark;
    }

    public int getAssignment() {
        return assignment;
    }

    public void setAssignment(int assignment) {
        this.assignment = assignment;
    }

    public int getCourseForAssignment() {
        return courseForAssignment;
    }

    public void setCourseForAssignment(int courseForAssignment) {
        this.courseForAssignment = courseForAssignment;
    }

    public int getCourse_ID() {
        return course_ID;
    }

    public void setCourse_ID(int course_ID) {
        this.course_ID = course_ID;
    }

    public String getCou_Title() {
        return cou_Title;
    }

    public void setCou_Title(String cou_Title) {
        this.cou_Title = cou_Title;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getStream() {
        return stream;
    }

    public void setStream(String stream) {
        this.stream = stream;
    }

    public Date getStart_Date() {
        return start_Date;
    }

    public void setStart_Date(Date start_Date) {
        this.start_Date = start_Date;
    }

    public Date getEnd_Date() {
        return end_Date;
    }

    public void setEnd_Date(Date end_Date) {
        this.end_Date = end_Date;
    }
}

package Model;

import java.util.Date;

public class TrainerPerCourse {
    private int tr_SSN;
    private String tr_Fname;
    private String tr_Lname;
    private Date tr_DOB;
    private int trainer;
    private int courseForTrainer;
    private int course_ID;
    private String cou_Title;
    private String type;
    private String Stream;
    private Date start_Date;
    private Date end_Date;

    public TrainerPerCourse(int tr_SSN, String tr_Fname, String tr_Lname, Date tr_DOB, int trainer, int courseForTrainer, int course_ID, String cou_Title, String type, String stream, Date start_Date, Date end_Date) {
        this.tr_SSN = tr_SSN;
        this.tr_Fname = tr_Fname;
        this.tr_Lname = tr_Lname;
        this.tr_DOB = tr_DOB;
        this.trainer = trainer;
        this.courseForTrainer = courseForTrainer;
        this.course_ID = course_ID;
        this.cou_Title = cou_Title;
        this.type = type;
        Stream = stream;
        this.start_Date = start_Date;
        this.end_Date = end_Date;
    }

    public int getTr_SSN() {
        return tr_SSN;
    }

    public void setTr_SSN(int tr_SSN) {
        this.tr_SSN = tr_SSN;
    }

    public String getTr_Fname() {
        return tr_Fname;
    }

    public void setTr_Fname(String tr_Fname) {
        this.tr_Fname = tr_Fname;
    }

    public String getTr_Lname() {
        return tr_Lname;
    }

    public void setTr_Lname(String tr_Lname) {
        this.tr_Lname = tr_Lname;
    }

    public Date getTr_DOB() {
        return tr_DOB;
    }

    public void setTr_DOB(Date tr_DOB) {
        this.tr_DOB = tr_DOB;
    }

    public int getTrainer() {
        return trainer;
    }

    public void setTrainer(int trainer) {
        this.trainer = trainer;
    }

    public int getCourseForTrainer() {
        return courseForTrainer;
    }

    public void setCourseForTrainer(int courseForTrainer) {
        this.courseForTrainer = courseForTrainer;
    }

    public int getCourse_ID() {
        return course_ID;
    }

    public void setCourse_ID(int course_ID) {
        this.course_ID = course_ID;
    }

    public String getCou_Title() {
        return cou_Title;
    }

    public void setCou_Title(String cou_Title) {
        this.cou_Title = cou_Title;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getStream() {
        return Stream;
    }

    public void setStream(String stream) {
        Stream = stream;
    }

    public Date getStart_Date() {
        return start_Date;
    }

    public void setStart_Date(Date start_Date) {
        this.start_Date = start_Date;
    }

    public Date getEnd_Date() {
        return end_Date;
    }

    public void setEnd_Date(Date end_Date) {
        this.end_Date = end_Date;
    }

    @Override
    public String toString() {
        return "TrainerPerCourse{" +
                "tr_SSN=" + tr_SSN +
                ", tr_Fname='" + tr_Fname + '\'' +
                ", tr_Lname='" + tr_Lname + '\'' +
                ", tr_DOB=" + tr_DOB +
                ", trainer=" + trainer +
                ", courseForTrainer=" + courseForTrainer +
                ", course_ID=" + course_ID +
                ", cou_Title='" + cou_Title + '\'' +
                ", type='" + type + '\'' +
                ", Stream='" + Stream + '\'' +
                ", start_Date=" + start_Date +
                ", end_Date=" + end_Date +
                '}';
    }
}

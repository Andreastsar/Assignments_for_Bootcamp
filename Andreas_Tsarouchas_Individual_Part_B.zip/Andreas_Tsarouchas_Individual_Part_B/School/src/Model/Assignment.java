package Model;

import java.util.Date;

public class Assignment {
    private int ass_Date;
    private String ass_Title;
    private Date sub_Date;
    private double oral_Mark;
    private double total_Mark;

    @Override
    public String toString() {
        return "Assignment{" +
                "ass_Date=" + ass_Date +
                ", ass_Title='" + ass_Title + '\'' +
                ", sub_Date=" + sub_Date +
                ", oral_Mark=" + oral_Mark +
                ", total_Mark=" + total_Mark +
                '}';
    }

    public Assignment(int ass_Date, String ass_Title, Date sub_Date, double oral_Mark, double total_Mark) {
        this.ass_Date = ass_Date;
        this.ass_Title = ass_Title;
        this.sub_Date = sub_Date;
        this.oral_Mark = oral_Mark;
        this.total_Mark = total_Mark;
    }

    public int getAss_Date() {
        return ass_Date;
    }

    public void setAss_Date(int ass_Date) {
        this.ass_Date = ass_Date;
    }

    public String getAss_Title() {
        return ass_Title;
    }

    public void setAss_Title(String ass_Title) {
        this.ass_Title = ass_Title;
    }

    public Date getSub_Date() {
        return sub_Date;
    }

    public void setSub_Date(Date sub_Date) {
        this.sub_Date = sub_Date;
    }

    public double getOral_Mark() {
        return oral_Mark;
    }

    public void setOral_Mark(double oral_Mark) {
        this.oral_Mark = oral_Mark;
    }

    public double getTotal_Mark() {
        return total_Mark;
    }

    public void setTotal_Mark(double total_Mark) {
        this.total_Mark = total_Mark;
    }
}
package Model;

import java.util.Date;

public class Trainer {
    private int tr_SSN;
    private String tr_Fname;
    private String tr_Lname;
    private Date tr_DOB;

    public Trainer(int tr_SSN, String tr_Fname, String tr_Lname, Date tr_DOB) {
        this.tr_SSN = tr_SSN;
        this.tr_Fname = tr_Fname;
        this.tr_Lname = tr_Lname;
        this.tr_DOB = tr_DOB;
    }

    @Override
    public String toString() {
        return "Trainer{" +
                "tr_SSN=" + tr_SSN +
                ", tr_Fname='" + tr_Fname + '\'' +
                ", tr_Lname='" + tr_Lname + '\'' +
                ", tr_DOB=" + tr_DOB +
                '}';
    }

    public int getTr_SSN() {
        return tr_SSN;
    }

    public void setTr_SSN(int tr_SSN) {
        this.tr_SSN = tr_SSN;
    }

    public String getTr_Fname() {
        return tr_Fname;
    }

    public void setTr_Fname(String tr_Fname) {
        this.tr_Fname = tr_Fname;
    }

    public String getTr_Lname() {
        return tr_Lname;
    }

    public void setTr_Lname(String tr_Lname) {
        this.tr_Lname = tr_Lname;
    }

    public Date getTr_DOB() {
        return tr_DOB;
    }

    public void setTr_DOB(Date tr_DOB) {
        this.tr_DOB = tr_DOB;
    }
}

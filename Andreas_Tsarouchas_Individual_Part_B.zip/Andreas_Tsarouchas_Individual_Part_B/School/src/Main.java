import dao.AssignmentDao;
import dao.CourseDao;
import dao.StudentDao;
import dao.TrainerDao;
import services.PrintData;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Print all Data for Individual Project B
        PrintData.printAllData();

        // User inputs data to DB

        // Create a new Student from user's input
        StudentDao.insertStudentToDB(StudentDao.createStudent(sc));

        // Create a new Trainer from user's input
        TrainerDao.insertTrainerToDB(TrainerDao.createTrainer(sc));

        // Create a new Assignment to DB
        AssignmentDao.insertAssignmentToDB(AssignmentDao.createAssignment(sc));

        // Create a new Course to DB
        CourseDao.insertCourseToDB(CourseDao.createCourse(sc));
    }
}
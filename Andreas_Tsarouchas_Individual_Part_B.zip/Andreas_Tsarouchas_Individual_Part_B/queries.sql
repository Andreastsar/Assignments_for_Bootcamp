-- 1. A list of all the students
select *
from student;
/*-----------------------------------------------------------------------------------------------------------------*/

-- 2. A list of all the trainers
select *
from trainer;
/*-----------------------------------------------------------------------------------------------------------------*/

-- 3. A list of all the assignments
select *
from assignment;
/*-----------------------------------------------------------------------------------------------------------------*/

-- 4. A list of all the courses
select *
from course;
/*-----------------------------------------------------------------------------------------------------------------*/

-- 5. A list of all the students per course

-- Το procedure αυτό φέρνει τους Students που ανήκουν στο συγκεκριμένο Course που ζητάμε.
DELIMITER &&
CREATE PROCEDURE get_students_in_course(IN n varchar(45))
BEGIN
	select *
    from student
    join studentcourse on student = Stu_SSN
    join course on Course_ID = CourseForStudent
    where Cou_Title = n;
END &&
DELIMITER ;

-- Φέρνουμε τους μαθητές / course χρησιμοποιώντας τον τίτλο του μαθήματος.
call get_students_in_course('CB1');
call get_students_in_course('CB2');
call get_students_in_course('CB3');
call get_students_in_course('CB4');
call get_students_in_course('CB5');
call get_students_in_course('CB6');
call get_students_in_course('CB7');
call get_students_in_course('CB8');
call get_students_in_course('CB9');
call get_students_in_course('CB10');
call get_students_in_course('CB11');
call get_students_in_course('CB12');
call get_students_in_course('CB13');
call get_students_in_course('CB14');

-- Εναλλακτικά φέρνουμε μια λίστα που δείχνει όλους τους Students/Course.
select *
from student
join studentcourse on stu_ssn = student
join course on Course_ID = CourseForStudent
order by Course_ID;
/*-----------------------------------------------------------------------------------------------------------------*/

-- 6. A list of all the trainers per course

-- Το procedure αυτό φέρνει τους Trainers που ανήκουν στο συγκεκριμένο Course που ζητάμε.
DELIMITER &&
CREATE PROCEDURE get_trainers_in_course(IN n varchar(45))
BEGIN
	select *
    from trainer
	join trainercourse on trainer = Tr_SSN
	join course on Course_ID = CourseForTrainer
    where Cou_Title = n;
END &&
DELIMITER ;

call get_trainers_in_course('CB1');
call get_trainers_in_course('CB2');
call get_trainers_in_course('CB3');
call get_trainers_in_course('CB4');
call get_trainers_in_course('CB5');
call get_trainers_in_course('CB6');
call get_trainers_in_course('CB7');
call get_trainers_in_course('CB8');
call get_trainers_in_course('CB9');
call get_trainers_in_course('CB10');
call get_trainers_in_course('CB11');
call get_trainers_in_course('CB12');
call get_trainers_in_course('CB13');
call get_trainers_in_course('CB14');

-- Εναλλακτικά φέρνουμε μια λίστα με όλους τους Trainers/Course.
select *
from trainer
join trainercourse on trainer = Tr_SSN
join course on Course_ID = CourseForTrainer
order by Course_ID;
/*-----------------------------------------------------------------------------------------------------------------*/

-- 7. A list of all the assignments per course

-- Το procedure αυτό φέρνει τα Assignments που ανήκουν στο συγκεκριμένο Course που ζητάμε.
DELIMITER &&
CREATE PROCEDURE get_assignments_in_course(IN n varchar(45))
BEGIN
	select *
    from assignment
	join assignmentcourse on assignment = Ass_id
	join course on course_id = courseforassignment
    where Cou_Title = n;
END &&
DELIMITER ;

call get_assignments_in_course('CB1');
call get_assignments_in_course('CB2');
call get_assignments_in_course('CB3');
call get_assignments_in_course('CB4');
call get_assignments_in_course('CB5');
call get_assignments_in_course('CB6');
call get_assignments_in_course('CB7');
call get_assignments_in_course('CB8');
call get_assignments_in_course('CB9');
call get_assignments_in_course('CB10');
call get_assignments_in_course('CB11');
call get_assignments_in_course('CB12');
call get_assignments_in_course('CB13');
call get_assignments_in_course('CB14');

-- Εναλλακτικά μέσω του query
select *
from assignment
join assignmentcourse on assignment = Ass_id
join course on course_id = courseforassignment
order by course_id;
/*-----------------------------------------------------------------------------------------------------------------*/

-- 8. A list of all the assignments per course per student
select *
from assignment
join assignmentcourse  on ass_id = assignment
join course on courseforassignment = course_id
join studentcourse on course_id = courseforstudent
join student on stu_ssn = student
order by stu_ssn;
/*-----------------------------------------------------------------------------------------------------------------*/

-- 9. A list of all the students that belong to more than one courses
select student
from studentcourse
group by CourseForStudent
having count(CourseForStudent) > 1;
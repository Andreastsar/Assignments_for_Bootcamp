During the development of this project, you need to do the implementation of a private school structure.
On this PART A, you are required to build a command prompt (console) application that does not connect to an RDBMS (database).
The application must ask from the command prompt to input data to all the entities, and it should give the option to add more than one entry at a time
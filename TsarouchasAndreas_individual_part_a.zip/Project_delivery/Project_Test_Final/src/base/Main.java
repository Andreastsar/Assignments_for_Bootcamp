package base;

import initializations.InitiateDBForTrainersPerCourse;
import initializations.InitiateDBforStudentsPerCourse;
import models.*;
import services.RegisterStudentToCourseService;
import services.RegisterTrainerToACourseService;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        //Create DB for Trainers Per Course
        InitiateDBForTrainersPerCourse dataTrainers = new InitiateDBForTrainersPerCourse();
        List<TrainersPerCourse> allTrainers = dataTrainers.createDB();
        InitiateDBForTrainersPerCourse syntheticDataForTrainers = new InitiateDBForTrainersPerCourse();
        List<TrainersPerCourse> allSyntheticTrainers = syntheticDataForTrainers.createSyntheticDB();
        //Create DB for Courses (including Students/Course + Assignments)
        InitiateDBforStudentsPerCourse dataStudents = new InitiateDBforStudentsPerCourse();
        List<Course> allCourses = dataStudents.createCourseDB();
        InitiateDBforStudentsPerCourse syntheticStudents = new InitiateDBforStudentsPerCourse();
        List<Course> allSyntheticCourses = syntheticStudents.createSyntheticCourseDB();

        System.out.println("*** Welcome to the BYTE ME private school for Coding! ***");
        System.out.println("Here you can begin your journey to programming!\n" +
                "Our school supports multiple Courses, Students, Trainers , Assignments and more! ");
        System.out.println("What would you like to do? Choose from the Options below!");
        System.out.println("----------------------------------------------------------------------------------");
        System.out.print("Would you like to: 1.Enter your own Data || 2.Use synthetic Data --> ");
        int chooseDataType = input.nextInt();
        // Write your own Data
        if (chooseDataType == 1) {
            boolean flag = false;
            while (!flag) {
                System.out.println("Pick an Option: ");
                System.out.println("1. Register as a Student for a Course and deliver Assignments");
                System.out.println("2. Register as a Trainer for a Course");
                System.out.println("3. Show all Students");
                System.out.println("4. Show all Students per Course");
                System.out.println("5. Show all Trainers Per Course");
                System.out.println("6. Show all Trainers");
                System.out.println("7. Show all Assignments");
                System.out.println("8. Show all Courses");
                System.out.println("9. Show all Assignments per Course");
                System.out.println("10. Show all Assignments per Student");
                System.out.println("11. Show Students that belong to more than one Course");
                System.out.println("12. Exit");
                int option = input.nextInt();
                // Option 1
                if (option == 1) {
                    RegisterStudentToCourseService inputStudent = new RegisterStudentToCourseService();
                    inputStudent.registerStudentToCourse(input, allCourses);
                }
                // Option 2
                if (option == 2) {
                    RegisterTrainerToACourseService inputTrainer = new RegisterTrainerToACourseService();
                    inputTrainer.registerTrainerToCourse(input, allTrainers);
                }
                // Option 3
                if (option == 3) {
                    ArrayList<Student> studentsOnly = new ArrayList<>();
                    for (Course x : allCourses) {
                        for (Student s : x.getStudentsPerCourse()) {
                            if ((!studentsOnly.contains(s) && !(s.getFirstName().equals("")))) {
                                studentsOnly.add(s);
                            }
                        }
                    }
                    System.out.println("Students of BYTE ME");
                    for (Student s : studentsOnly) {
                        System.out.println(s.onlySudentsName());
                    }
                    System.out.println("=======");
                }
                // Option 4
                if (option == 4) {
                    ArrayList<Course> studentsPerCourse = new ArrayList<>();
                    studentsPerCourse.addAll(allCourses);
                    for (Course c : studentsPerCourse) {
                        c.getStudentsPerCourse().remove(0);
                    }
                    for (int i = 0; i < studentsPerCourse.size(); i++) {
                        System.out.println("Course");
                        System.out.println(studentsPerCourse.get(i).onlyStudentsPerCourse());
                        System.out.println("=======");
                    }
                }
                // Option 5
                if (option == 5) {
                    for (int i = 0; i < allTrainers.size(); i++) {
                        allTrainers.get(i).getTrainersPerCourse().remove(0);
                    }
                    for (int i = 0; i < allTrainers.size(); i++) {
                        System.out.println("Trainers per Course:");
                        System.out.println(allTrainers.get(i).getTrainersPerCourse().toString());
                        System.out.println("=======");
                    }
                }
                // Option 6
                if (option == 6) {
                    ArrayList<Trainer> trainersList = new ArrayList<>();
                    trainersList.add(new Trainer("", "", "", ""));
                    for (TrainersPerCourse x : allTrainers) {
                        for (Trainer t : x.getTrainersPerCourse()) {
                            if (!trainersList.contains(t)) {
                                trainersList.add(t);
                            }
                        }
                    }
                    trainersList.remove(0);
                    System.out.println("---Trainers List---");
                    System.out.println(trainersList);
                    System.out.println("=======");
                }
                // Option 7
                if (option == 7) {
                    for (Course c : allCourses) {
                        for (Student s : c.getStudentsPerCourse()) {
                            System.out.println(s.getStudentsAssignments());
                        }
                    }
                }
                // Option 8
                if (option == 8) {
                    for (Course c : allCourses) {
                        System.out.println(c.toString());
                    }
                }
                // Option 9
                if (option == 9) {
                    for (Course c : allCourses) {
                        System.out.println("Course:" + c.getTitle() + " - Stream:" + c.getStream() + " - Type:" + c.getType());
                        for (Student s : c.getStudentsPerCourse()) {
                            System.out.println("Assignments: " + s.getStudentsAssignments());
                            System.out.println("----------");
                        }
                    }
                }
                // Option 10
                if (option == 10) {
                    for (Course c : allCourses) {
                        for (Student s : c.getStudentsPerCourse()) {
                            System.out.println("Student " + s.getFirstName() + " " + s.getLastName() + " assignments: ");
                            System.out.println(s.getStudentsAssignments());
                        }
                    }
                }
                // Option 11
                if (option == 11) {
                    ArrayList<Student> studentBelongsToMoreCourses = new ArrayList<>();
                    ArrayList<Student> studentsToMoreThanOneFinal = new ArrayList<>();
                    for (Course c : allCourses) {
                        studentBelongsToMoreCourses.addAll(c.getStudentsPerCourse());
                    }
                    for (Student s : studentBelongsToMoreCourses) {
                        int freq = Collections.frequency(studentBelongsToMoreCourses, s);
                        if (freq > 1) {
                            studentsToMoreThanOneFinal.add(s);
                        }
                    }
                    System.out.println("Students that belong to more than one Course");
                    System.out.println(studentsToMoreThanOneFinal);
                    System.out.println("=======");
                }
                // Option 12
                if (option == 12) {
                    System.out.println("Thank you for choosing our School!\n***Have a nice journey!***\nBYTE ME Copyright 2022");
                    break;
                }
            }
            // Use Synthetic Data
        } else if (chooseDataType == 2) {
            boolean syntheticFlag = false;
            while (!syntheticFlag) {
                System.out.println("1. Synthetic Data for Trainers per Course");
                System.out.println("2. Synthetic Data for all Trainers");
                System.out.println("3. Show all Synthetic Students");
                System.out.println("4. Show all Synthetic Students per Course");
                System.out.println("5. Show all Synthetic Assignments");
                System.out.println("6. Show all Synthetic Courses");
                System.out.println("7. Show all Synthetic Assignments per Course");
                System.out.println("8. Show all Synthetic Assignments per Student");
                System.out.println("9. Show Synthetic Students that belong to more than one Course");
                System.out.println("10.Exit");
                int synthetic = input.nextInt();
                if (synthetic == 1) {
                    for (int i = 0; i < allSyntheticTrainers.size(); i++) {
                        System.out.println("Synthetic Trainers per Course:");
                        System.out.println(allSyntheticTrainers.get(i).getTrainersPerCourse().toString());
                        System.out.println("=======");
                    }
                } else if (synthetic == 2) {
                    ArrayList<Trainer> syntheticTrainerList = new ArrayList<>();
                    syntheticTrainerList.add(new Trainer("", "", "", ""));
                    for (TrainersPerCourse x : allSyntheticTrainers) {
                        for (Trainer t : x.getTrainersPerCourse()) {
                            if (!syntheticTrainerList.contains(t)) {
                                syntheticTrainerList.add(t);
                            }
                        }
                    }
                    syntheticTrainerList.remove(0);
                    System.out.println("---Synthetic Trainers List---");
                    System.out.println(syntheticTrainerList);
                    System.out.println("=======");
                } else if (synthetic == 3) {
                    ArrayList<Student> syntheticStudentsOnly = new ArrayList<>();
                    for (Course x : allSyntheticCourses) {
                        for (Student s : x.getStudentsPerCourse()) {
                            if ((!syntheticStudentsOnly.contains(s) && !(s.getFirstName().equals("")))) {
                                syntheticStudentsOnly.add(s);
                            }
                        }
                    }
                    System.out.println("Students of BYTE ME");
                    for (Student s : syntheticStudentsOnly) {
                        System.out.println(s.onlySudentsName());
                    }
                    System.out.println("=======");
                } else if (synthetic == 4) {
                    ArrayList<Course> syntheticStudentsPerCourse = new ArrayList<>();
                    syntheticStudentsPerCourse.addAll(allSyntheticCourses);
                    for (Course c : syntheticStudentsPerCourse) {
                        c.getStudentsPerCourse().remove(0);
                    }
                    for (int i = 0; i < syntheticStudentsPerCourse.size(); i++) {
                        System.out.println("Course");
                        System.out.println(syntheticStudentsPerCourse.get(i).onlyStudentsPerCourse());
                        System.out.println("=======");
                    }
                } else if (synthetic == 5) {
                    for (Course c : allSyntheticCourses) {
                        for (Student s : c.getStudentsPerCourse()) {
                            System.out.println(s.getStudentsAssignments());
                        }
                    }
                } else if (synthetic == 6) {
                    for (Course c : allSyntheticCourses) {
                        System.out.println(c.toString());
                    }
                } else if (synthetic == 7) {
                    for (Course c : allSyntheticCourses) {
                        System.out.println("Course:" + c.getTitle() + " - Stream:" + c.getStream() + " - Type:" + c.getType());
                        for (Student s : c.getStudentsPerCourse()) {
                            System.out.println("Assignments: " + s.getStudentsAssignments());
                            System.out.println("----------");
                        }
                    }
                } else if (synthetic == 8) {
                    for (Course c : allSyntheticCourses) {
                        for (Student s : c.getStudentsPerCourse()) {
                            System.out.println("Student " + s.getFirstName() + " " + s.getLastName() + " assignments: ");
                            System.out.println(s.getStudentsAssignments());
                        }
                    }
                } else if (synthetic == 9) {
                    ArrayList<Student> syntheticStudentBelongsToMoreCourses = new ArrayList<>();
                    ArrayList<Student> syntheticStudentsToMoreThanOneFinal = new ArrayList<>();
                    for (Course c : allSyntheticCourses) {
                        syntheticStudentBelongsToMoreCourses.addAll(c.getStudentsPerCourse());
                    }
                    for (Student s : syntheticStudentBelongsToMoreCourses) {
                        int freq = Collections.frequency(syntheticStudentBelongsToMoreCourses, s);
                        if (freq > 1) {
                            syntheticStudentsToMoreThanOneFinal.add(s);
                        }
                    }
                    System.out.println("Students that belong to more than one Course");
                    System.out.println(syntheticStudentsToMoreThanOneFinal);
                    System.out.println("=======");
                } else {
                    System.out.println("Thank you for choosing our School!\n***Have a nice journey!***\nBYTE ME Copyright 2022");
                    break;
                }

            }
        }
    }
}
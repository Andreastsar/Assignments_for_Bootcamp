package models;

import java.time.LocalDate;
import java.util.ArrayList;

public class Student {
    private String firstName;
    private String lastName;
    private LocalDate dateOfBirth;
    private double tuitionFees;
    private String amka;
    private ArrayList<Assignment> studentsAssignments;

    public Student(String firstName, String lastName, LocalDate dateOfBirth, double tuitionFees, String amka) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;
        this.tuitionFees = tuitionFees;
        this.amka = amka;
        this.studentsAssignments = new ArrayList<>();
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public double getTuitionFees() {
        return tuitionFees;
    }

    public void setTuitionFees(double tuitionFees) {
        this.tuitionFees = tuitionFees;
    }

    public String getAmka() {
        return amka;
    }

    public void setAmka(String amka) {
        this.amka = amka;
    }

    public ArrayList<Assignment> getStudentsAssignments() {
        return studentsAssignments;
    }

    public void setStudentsAssignments(ArrayList<Assignment> studentsAssignments) {
        this.studentsAssignments = studentsAssignments;
    }

    public String onlySudentsName(){
        return "Student{Name:'" + firstName + "', Surname:'" + lastName + "'}";
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Student that = (Student) obj;
        return  (this.amka.equals(that.amka));
    }

    @Override
    public String toString() {
        return "Student{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", dateOfBirth=" + dateOfBirth +
                ", tuitionFees=" + tuitionFees +
                ", amka='" + amka + '\'' +
                ", studentsAssignments=" + studentsAssignments +
                '}';
    }
}

package models;

import java.time.LocalDate;
import java.util.ArrayList;

public class Course {
    private String title;
    private String stream;
    private String type;
    private LocalDate start_date;
    private LocalDate end_date;
    private ArrayList<Student> studentsPerCourse;

    //Constructor
    public Course() {
    }

    public Course(String title, String stream, String type) {
        this.title = title;
        this.stream = stream;
        this.type = type;
        this.start_date = LocalDate.of(2022,5,2);
        this.end_date = LocalDate.of(2022,8,29);
        this.studentsPerCourse = new ArrayList<>();
    }

    public ArrayList<Student> getStudentsPerCourse() {
        return studentsPerCourse;
    }

    public void setStudentsPerCourse(ArrayList<Student> studentsPerCourse) {
        this.studentsPerCourse = studentsPerCourse;
    }


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getStream() {
        return stream;
    }

    public void setStream(String stream) {
        this.stream = stream;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public LocalDate getStart_date() {
        return start_date;
    }

    public void setStart_date(LocalDate start_date) {
        this.start_date = start_date;
    }

    public LocalDate getEnd_date() {
        return end_date;
    }

    public void setEnd_date(LocalDate end_date) {
        this.end_date = end_date;
    }

    public String onlyStudentsPerCourse() {
        return "{" + studentsPerCourse + "}";
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Course that = (Course) obj;
        return  (this.title.equals(that.title) && this.stream.equals(that.stream) && this.type.equals(that.type));
    }

    @Override
    public String toString() {
        return "Course{" +
                "Title:'" + title + '\'' +
                ", Stream:'" + stream + '\'' +
                ", Type:'" + type + '\'' +
                ", Starts:" + start_date +
                ", Ends:" + end_date +
                '}';
    }
}
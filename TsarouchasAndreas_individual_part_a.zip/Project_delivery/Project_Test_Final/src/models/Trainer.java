package models;

public class Trainer {
    private String firstName;
    private String lastName;
    private String subject;
    private String amka;

    public Trainer() {
    }

    public Trainer(String firstName, String lastName, String subject, String amka) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.subject = subject;
        this.amka = amka;
    }

    public String getAmka() {
        return amka;
    }

    public void setAmka(String amka) {
        this.amka = amka;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override   // Checks if this trainer already exists.
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Trainer that = (Trainer) obj;
        return  (this.amka.equals(that.amka));
    }

    @Override
    public String toString() {
        return "{" +
                "Name:'" + firstName + '\'' +
                ", Surname:'" + lastName + '\'' +
                ", Subject:'" + subject + '\'' +
                ", AMKA:'" + amka + '\'' +
                '}';
    }
}

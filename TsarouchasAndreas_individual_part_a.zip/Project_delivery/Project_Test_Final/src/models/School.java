package models;

import java.util.ArrayList;

public class School {
    private String name = "BYTE ME";
    private ArrayList<Student> students;
}

package models;

import java.util.ArrayList;

public class TrainersPerCourse{
    private Course course;
    private ArrayList<Trainer> trainers;

    public TrainersPerCourse(Course course) {
        this.course = course;
        this.trainers = new ArrayList<Trainer>();
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

    public ArrayList<Trainer> getTrainersPerCourse() {
        return trainers;
    }

    public void setTrainersPerCourse(ArrayList<Trainer> trainersPerCourse) {
        this.trainers = trainersPerCourse;
    }


    // Add Trainer to a Course
    public void addTrainerToCourse(Trainer trainer){
        trainers.add(trainer);
    }

    @Override
    public String toString() {
        return "TrainersPerCourse{" +
                "course=" + course +
                ", trainersPerCourse=" + trainers +
                '}';
    }
}

package initializations;
import models.Course;
import models.Trainer;
import models.TrainersPerCourse;
import java.util.List;

public class InitiateDBForTrainersPerCourse {
    public List<TrainersPerCourse> createDB() {

        // Course CB1
        Course cb1jf = new Course("CB1","Java", "FullTime");
        Course cb1jp = new Course("CB1","Java", "PartTime");
        Course cb1pf = new Course("CB1","Python", "FullTime");
        Course cb1pp = new Course("CB1","Python", "PartTime");

        // Course CB2
        Course cb2rf = new Course("CB2","Ruby", "FullTime");
        Course cb2rp = new Course("CB2","Ruby", "PartTime");
        Course cb2cf = new Course("CB2","C#", "FullTime");
        Course cb2cp = new Course("CB2","C#", "PartTime");


        // Creating db for each CB
        TrainersPerCourse tpc1 = new TrainersPerCourse(cb1jf);
        TrainersPerCourse tpc2 = new TrainersPerCourse(cb1jp);
        TrainersPerCourse tpc3 = new TrainersPerCourse(cb1pf);
        TrainersPerCourse tpc4 = new TrainersPerCourse(cb1pp);

        TrainersPerCourse tpc5 = new TrainersPerCourse(cb2rf);
        TrainersPerCourse tpc6 = new TrainersPerCourse(cb2rp);
        TrainersPerCourse tpc7 = new TrainersPerCourse(cb2cf);
        TrainersPerCourse tpc8 = new TrainersPerCourse(cb2cp);

        tpc1.addTrainerToCourse(new Trainer("","","",""));
        tpc2.addTrainerToCourse(new Trainer("","","",""));
        tpc3.addTrainerToCourse(new Trainer("","","",""));
        tpc4.addTrainerToCourse(new Trainer("","","",""));
        tpc5.addTrainerToCourse(new Trainer("","","",""));
        tpc6.addTrainerToCourse(new Trainer("","","",""));
        tpc7.addTrainerToCourse(new Trainer("","","",""));
        tpc8.addTrainerToCourse(new Trainer("","","",""));


        return List.of(tpc1,tpc2,tpc3,tpc4,tpc5,tpc6,tpc7,tpc8);    // allTrainers
    }

    public List<TrainersPerCourse> createSyntheticDB() {

        // Course CB1
        Course cb1jf = new Course("CB1","Java", "FullTime");
        Course cb1jp = new Course("CB1","Java", "PartTime");
        Course cb1pf = new Course("CB1","Python", "FullTime");
        Course cb1pp = new Course("CB1","Python", "PartTime");

        // Course CB2
        Course cb2rf = new Course("CB2","Ruby", "FullTime");
        Course cb2rp = new Course("CB2","Ruby", "PartTime");
        Course cb2cf = new Course("CB2","C#", "FullTime");
        Course cb2cp = new Course("CB2","C#", "PartTime");


        // Creating db for each CB
        TrainersPerCourse tpc1 = new TrainersPerCourse(cb1jf);
        TrainersPerCourse tpc2 = new TrainersPerCourse(cb1jp);
        TrainersPerCourse tpc3 = new TrainersPerCourse(cb1pf);
        TrainersPerCourse tpc4 = new TrainersPerCourse(cb1pp);

        TrainersPerCourse tpc5 = new TrainersPerCourse(cb2rf);
        TrainersPerCourse tpc6 = new TrainersPerCourse(cb2rp);
        TrainersPerCourse tpc7 = new TrainersPerCourse(cb2cf);
        TrainersPerCourse tpc8 = new TrainersPerCourse(cb2cp);

        tpc1.addTrainerToCourse(new Trainer("Giannis","Bond","Java - Full Time","1234123456"));
        tpc1.addTrainerToCourse(new Trainer("Maria","Ioannou","Java - Full Time","6636456555"));
        tpc1.addTrainerToCourse(new Trainer("Giannis","Anastasiou","Java - Full Time","111214222"));
        tpc1.addTrainerToCourse(new Trainer("Nikos","Ioannou","Java - Full Time","3332534555"));
        tpc1.addTrainerToCourse(new Trainer("Pantelis","Spyropoylos","Java - Full Time","987124654"));

        tpc2.addTrainerToCourse(new Trainer("Orestis","Bond","Java - Part Time","6547453185"));
        tpc2.addTrainerToCourse(new Trainer("Marianiki","Ioannou","Java - Part Time","9865437354"));
        tpc2.addTrainerToCourse(new Trainer("Aggelos","Anastasiou","Java - Part Time","111241222"));
        tpc2.addTrainerToCourse(new Trainer("Nikos","Pappas","Java - Part Time","1596814234"));
        tpc2.addTrainerToCourse(new Trainer("Pantelis","Spyropoylos","Java - Part Time","9852347654"));

        tpc3.addTrainerToCourse(new Trainer("Andreas","Bond","Python - Full Time","1237564456"));
        tpc3.addTrainerToCourse(new Trainer("Kostas","Ioannou","Python - Full Time","6636456555"));
        tpc3.addTrainerToCourse(new Trainer("Anna","Anastasiou","Python - Full Time","1125341222"));
        tpc3.addTrainerToCourse(new Trainer("Giannis","Ioannou","Python - Full Time","3336345555"));
        tpc3.addTrainerToCourse(new Trainer("Efi","Spyropoylos","Python - Full Time","98725654"));

        tpc4.addTrainerToCourse(new Trainer("Panagiotis","Bond","Python - Part Time","1225343456"));
        tpc4.addTrainerToCourse(new Trainer("Ariadni","Ioannou","Python - Part Time","6667546555"));
        tpc4.addTrainerToCourse(new Trainer("Nefeli","Anastasiou","Python - Part Time","1119768222"));
        tpc4.addTrainerToCourse(new Trainer("Iosif","Ioannou","Python - Part Time","3338567555"));
        tpc4.addTrainerToCourse(new Trainer("Markos","Spyropoylos","Python - Part Time","9876634554"));

        tpc5.addTrainerToCourse(new Trainer("Anastasia","Bond","Ruby - Full Time","1234124356"));
        tpc5.addTrainerToCourse(new Trainer("Areti","Ioannou","Ruby - Full Time","6662354555"));
        tpc5.addTrainerToCourse(new Trainer("Eleni","Anastasiou","Ruby - Full Time","1116354222"));
        tpc5.addTrainerToCourse(new Trainer("Alexandra","Ioannou","Ruby - Full Time","3336543555"));
        tpc5.addTrainerToCourse(new Trainer("Fotis","Spyropoylos","Ruby - Full Time","9873456654"));

        tpc6.addTrainerToCourse(new Trainer("Chris","Bond","Ruby - Part Time","1234345656"));
        tpc6.addTrainerToCourse(new Trainer("Stella","Ioannou","Ruby - Part Time","6634566555"));
        tpc6.addTrainerToCourse(new Trainer("Alexandros","Anastasiou","Ruby - Part Time","1112345622"));
        tpc6.addTrainerToCourse(new Trainer("Nikos","Ioannou","Ruby - Part Time","3333456555"));
        tpc6.addTrainerToCourse(new Trainer("Vaggelis","Spyropoylos","Ruby - Part Time","9873546654"));

        tpc7.addTrainerToCourse(new Trainer("Dafni","Bond","C# - Full Time","1233456456"));
        tpc7.addTrainerToCourse(new Trainer("Giorgos","Ioannou","C# - Full Time","6665345655"));
        tpc7.addTrainerToCourse(new Trainer("Eva","Anastasiou","C# - Full Time","1113456222"));
        tpc7.addTrainerToCourse(new Trainer("Grigoris","Ioannou","C# - Full Time","23452345"));
        tpc7.addTrainerToCourse(new Trainer("Laertis","Spyropoylos","C# - Full Time","34567465"));

        tpc8.addTrainerToCourse(new Trainer("Sotiris","Bond","C# - Part Time","23452345"));
        tpc8.addTrainerToCourse(new Trainer("Evgenia","Ioannou","C# - Part Time","234563546"));
        tpc8.addTrainerToCourse(new Trainer("Anna","Anastasiou","C# - Part Time","3688456"));
        tpc8.addTrainerToCourse(new Trainer("Panagiota","Ioannou","C# - Part Time","2325452"));
        tpc8.addTrainerToCourse(new Trainer("Pantelis","Spyropoylos","C# - Part Time","987654"));


        return List.of(tpc1,tpc2,tpc3,tpc4,tpc5,tpc6,tpc7,tpc8);    // allSyntheticTrainers
    }
}
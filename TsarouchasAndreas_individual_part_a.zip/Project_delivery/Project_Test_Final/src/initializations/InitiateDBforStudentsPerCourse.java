package initializations;

import models.Assignment;
import models.Course;
import models.Student;

import java.time.LocalDate;
import java.util.List;

public class InitiateDBforStudentsPerCourse {

    public List<Course> createCourseDB() {

        // Course CB1
        Course cb1jf = new Course("CB1","Java", "FullTime");
        Course cb1jp = new Course("CB1","Java", "PartTime");
        Course cb1pf = new Course("CB1","Python", "FullTime");
        Course cb1pp = new Course("CB1","Python", "PartTime");

        // Course CB2
        Course cb2rf = new Course("CB2","Ruby", "FullTime");
        Course cb2rp = new Course("CB2","Ruby", "PartTime");
        Course cb2cf = new Course("CB2","C#", "FullTime");
        Course cb2cp = new Course("CB2","C#", "PartTime");

        cb1jf.getStudentsPerCourse().add(new Student("","", LocalDate.of(2000,1,1),1,""));
        cb1jp.getStudentsPerCourse().add(new Student("","", LocalDate.of(2000,1,1),1,""));
        cb1pf.getStudentsPerCourse().add(new Student("","", LocalDate.of(2000,1,1),1,""));
        cb1pp.getStudentsPerCourse().add(new Student("","", LocalDate.of(2000,1,1),1,""));
        cb2rf.getStudentsPerCourse().add(new Student("","", LocalDate.of(2000,1,1),1,""));
        cb2rp.getStudentsPerCourse().add(new Student("","", LocalDate.of(2000,1,1),1,""));
        cb2cf.getStudentsPerCourse().add(new Student("","", LocalDate.of(2000,1,1),1,""));
        cb2cp.getStudentsPerCourse().add(new Student("","", LocalDate.of(2000,1,1),1,""));

        return List.of(cb1jf,cb1jp,cb1pf,cb1pp,cb2rf,cb2rp,cb2cf,cb2cp);   // returns list of all courses
    }

    public List<Course> createSyntheticCourseDB() {

        // Course CB1
        Course cb1jf = new Course("CB1","Java", "FullTime");
        Course cb1jp = new Course("CB1","Java", "PartTime");
        Course cb1pf = new Course("CB1","Python", "FullTime");
        Course cb1pp = new Course("CB1","Python", "PartTime");

        // Course CB2
        Course cb2rf = new Course("CB2","Ruby", "FullTime");
        Course cb2rp = new Course("CB2","Ruby", "PartTime");
        Course cb2cf = new Course("CB2","C#", "FullTime");
        Course cb2cp = new Course("CB2","C#", "PartTime");

        // 1
        cb1jf.getStudentsPerCourse().add(new Student("Andreas","Tsarouchas",
                LocalDate.of(1986,10,24),500,"1122334455"));
        cb1jf.getStudentsPerCourse().add(new Student("Giannis","Papadopoylos",
                LocalDate.of(2006,1,2),500,"1122331895"));
        cb1jf.getStudentsPerCourse().add(new Student("Orestis","Makris",
                LocalDate.of(1996,10,4),500,"11654455"));
        cb1jf.getStudentsPerCourse().get(0).getStudentsAssignments().add(0,new Assignment("CB1","Java - Fulltime",LocalDate.of(1,1,1),1,1));
        cb1jf.getStudentsPerCourse().get(0).getStudentsAssignments().add(1,new Assignment("CB2","Ruby - Fulltime",LocalDate.of(1,1,1),1,1));
        cb1jf.getStudentsPerCourse().get(1).getStudentsAssignments().add(0,new Assignment("CB1","Java - Fulltime",LocalDate.of(1,1,1),1,1));
        cb1jf.getStudentsPerCourse().get(1).getStudentsAssignments().add(1,new Assignment("CB2","Ruby - Fulltime",LocalDate.of(1,1,1),1,1));
        cb1jf.getStudentsPerCourse().get(2).getStudentsAssignments().add(0,new Assignment("CB1","Java - Fulltime",LocalDate.of(1,1,1),1,1));
        cb1jf.getStudentsPerCourse().get(2).getStudentsAssignments().add(1,new Assignment("CB2","Ruby - Fulltime",LocalDate.of(1,1,1),1,1));

        // 2
        cb1jp.getStudentsPerCourse().add(new Student("Andreas","Tsarouchas",
                LocalDate.of(1986,10,24),500,"1122334455"));
        cb1jp.getStudentsPerCourse().add(new Student("Giannis","Papadopoylos",
                LocalDate.of(2006,1,2),500,"1123455"));
        cb1jp.getStudentsPerCourse().add(new Student("Eftixis","Makris",
                LocalDate.of(1996,10,4),500,"1162355"));
        cb1jp.getStudentsPerCourse().get(0).getStudentsAssignments().add(0,new Assignment("CB1","Java - Fulltime",LocalDate.of(1,1,1),1,1));
        cb1jp.getStudentsPerCourse().get(0).getStudentsAssignments().add(1,new Assignment("CB2","Ruby - Fulltime",LocalDate.of(1,1,1),1,1));
        cb1jp.getStudentsPerCourse().get(1).getStudentsAssignments().add(0,new Assignment("CB1","Java - Fulltime",LocalDate.of(1,1,1),1,1));
        cb1jp.getStudentsPerCourse().get(1).getStudentsAssignments().add(1,new Assignment("CB2","Ruby - Fulltime",LocalDate.of(1,1,1),1,1));
        cb1jp.getStudentsPerCourse().get(2).getStudentsAssignments().add(0,new Assignment("CB1","Java - Fulltime",LocalDate.of(1,1,1),1,1));
        cb1jp.getStudentsPerCourse().get(2).getStudentsAssignments().add(1,new Assignment("CB2","Ruby - Fulltime",LocalDate.of(1,1,1),1,1));

        cb1jp.getStudentsPerCourse().add(new Student("","", LocalDate.of(2000,1,1),1,""));
        cb1pf.getStudentsPerCourse().add(new Student("","", LocalDate.of(2000,1,1),1,""));
        cb1pp.getStudentsPerCourse().add(new Student("","", LocalDate.of(2000,1,1),1,""));
        cb2rf.getStudentsPerCourse().add(new Student("","", LocalDate.of(2000,1,1),1,""));
        cb2rp.getStudentsPerCourse().add(new Student("","", LocalDate.of(2000,1,1),1,""));
        cb2cf.getStudentsPerCourse().add(new Student("","", LocalDate.of(2000,1,1),1,""));
        cb2cp.getStudentsPerCourse().add(new Student("","", LocalDate.of(2000,1,1),1,""));

        return List.of(cb1jf,cb1jp,cb1pf,cb1pp,cb2rf,cb2rp,cb2cf,cb2cp);   // returns list of all courses
    }
}

package services;

import models.Trainer;
import models.TrainersPerCourse;

import java.util.List;
import java.util.Scanner;

public class RegisterTrainerToACourseService {

    public void registerTrainerToCourse(Scanner input, List<TrainersPerCourse> allTrainers) {
        System.out.println("Pick a Course you want to register to: ");
        System.out.println("1. CB1 - Java - FullTime\n" +
                "2. CB1 - Java - PartTime" +
                "\n3. CB1 - Python - FullTime" +
                "\n4. CB1 - Python - PartTime" +
                "\n5. CB2 - Ruby - FullTime" +
                "\n6. CB2 - Ruby - PartTime" +
                "\n7. CB2 - C# - FullTime" +
                "\n8. CB2 - C# - PartTime");

        int courseChoice = input.nextInt();
        switch (courseChoice) {
            case 1:
                boolean trainerDoesExists = false;
                while (!trainerDoesExists) {
                    input.nextLine();
                    System.out.println("Enter your AMKA: ");
                    String inputAmka = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter your Name: ");
                    String inputName = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter your Surname: ");
                    String inputSurname = input.nextLine().trim().toUpperCase();

                    Trainer pickTrainer = new Trainer(inputName, inputSurname, "Java - Full Time", inputAmka);

                    if (allTrainers.get(0).getTrainersPerCourse().contains(pickTrainer)) {
                        System.out.println("***Already Registered!***\nRegister a new Trainer!\n=======");
                        break;
                    } else {
                        allTrainers.get(0).addTrainerToCourse(pickTrainer);
                        System.out.println("***Registration completed succesfully!***\n========");
                        trainerDoesExists = true;
                    }
                }
                break;
            case 2:
                boolean trainerDoesExists2 = false;
                while (!trainerDoesExists2) {
                    input.nextLine();
                    System.out.println("Enter your AMKA: ");
                    String inputAmka = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter your Name: ");
                    String inputName = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter your Surname: ");
                    String inputSurname = input.nextLine().trim().toUpperCase();

                    Trainer pickTrainer = new Trainer(inputName, inputSurname, "Java - Part Time", inputAmka);

                    if (allTrainers.get(1).getTrainersPerCourse().contains(pickTrainer)) {
                        System.out.println("***Already Registered!***\nRegister a new Trainer!\n=======");
                        break;
                    } else {
                        allTrainers.get(1).addTrainerToCourse(pickTrainer);
                        System.out.println("***Registration completed succesfully!***\n========");
                        trainerDoesExists2 = true;
                    }
                }
                break;
            case 3:
                boolean trainerDoesExists3 = false;
                while (!trainerDoesExists3) {
                    input.nextLine();
                    System.out.println("Enter your AMKA: ");
                    String inputAmka = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter your Name: ");
                    String inputName = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter your Surname: ");
                    String inputSurname = input.nextLine().trim().toUpperCase();

                    Trainer pickTrainer = new Trainer(inputName, inputSurname, "Python - Full Time", inputAmka);

                    if (allTrainers.get(2).getTrainersPerCourse().contains(pickTrainer)) {
                        System.out.println("***Already Registered!***\nRegister a new Trainer!\n=======");
                        break;
                    } else {
                        allTrainers.get(2).addTrainerToCourse(pickTrainer);
                        System.out.println("***Registration completed succesfully!***\n========");
                        trainerDoesExists3 = true;
                    }
                }
                break;
            case 4:
                boolean trainerDoesExists4 = false;
                while (!trainerDoesExists4) {
                    input.nextLine();
                    System.out.println("Enter your AMKA: ");
                    String inputAmka = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter your Name: ");
                    String inputName = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter your Surname: ");
                    String inputSurname = input.nextLine().trim().toUpperCase();

                    Trainer pickTrainer = new Trainer(inputName, inputSurname, "Python - Part Time", inputAmka);

                    if (allTrainers.get(3).getTrainersPerCourse().contains(pickTrainer)) {
                        System.out.println("***Already Registered!***\nRegister a new Trainer!\n=======");
                        break;
                    } else {
                        allTrainers.get(3).addTrainerToCourse(pickTrainer);
                        System.out.println("***Registration completed succesfully!***\n========");
                        trainerDoesExists4 = true;
                    }
                }
                break;
            case 5:
                boolean trainerDoesExists5 = false;
                while (!trainerDoesExists5) {
                    input.nextLine();
                    System.out.println("Enter your AMKA: ");
                    String inputAmka = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter your Name: ");
                    String inputName = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter your Surname: ");
                    String inputSurname = input.nextLine().trim().toUpperCase();

                    Trainer pickTrainer = new Trainer(inputName, inputSurname, "Ruby - Full Time", inputAmka);

                    if (allTrainers.get(4).getTrainersPerCourse().contains(pickTrainer)) {
                        System.out.println("***Already Registered!***\nRegister a new Trainer!\n=======");
                        break;
                    } else {
                        allTrainers.get(4).addTrainerToCourse(pickTrainer);
                        System.out.println("***Registration completed succesfully!***\n========");
                        trainerDoesExists5 = true;
                    }
                }
                break;
            case 6:
                boolean trainerDoesExists6 = false;
                while (!trainerDoesExists6) {
                    input.nextLine();
                    System.out.println("Enter your AMKA: ");
                    String inputAmka = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter your Name: ");
                    String inputName = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter your Surname: ");
                    String inputSurname = input.nextLine().trim().toUpperCase();

                    Trainer pickTrainer = new Trainer(inputName, inputSurname, "Ruby - Part Time", inputAmka);

                    if (allTrainers.get(5).getTrainersPerCourse().contains(pickTrainer)) {
                        System.out.println("***Already Registered!***\nRegister a new Trainer!\n=======");
                        break;
                    } else {
                        allTrainers.get(5).addTrainerToCourse(pickTrainer);
                        System.out.println("***Registration completed succesfully!***\n========");
                        trainerDoesExists6 = true;
                    }
                }
                break;
            case 7:
                boolean trainerDoesExists7 = false;
                while (!trainerDoesExists7) {
                    input.nextLine();
                    System.out.println("Enter your AMKA: ");
                    String inputAmka = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter your Name: ");
                    String inputName = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter your Surname: ");
                    String inputSurname = input.nextLine().trim().toUpperCase();

                    Trainer pickTrainer = new Trainer(inputName, inputSurname, "C# - Full Time", inputAmka);

                    if (allTrainers.get(6).getTrainersPerCourse().contains(pickTrainer)) {
                        System.out.println("***Already Registered!***\nRegister a new Trainer!\n=======");
                        break;
                    } else {
                        allTrainers.get(6).addTrainerToCourse(pickTrainer);
                        System.out.println("***Registration completed succesfully!***\n========");
                        trainerDoesExists7 = true;
                    }
                }
                break;
            case 8:
                boolean trainerDoesExists8 = false;
                while (!trainerDoesExists8) {
                    input.nextLine();
                    System.out.println("Enter your AMKA: ");
                    String inputAmka = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter your Name: ");
                    String inputName = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter your Surname: ");
                    String inputSurname = input.nextLine().trim().toUpperCase();

                    Trainer pickTrainer = new Trainer(inputName, inputSurname, "C# - Part Time", inputAmka);

                    if (allTrainers.get(7).getTrainersPerCourse().contains(pickTrainer)) {
                        System.out.println("***Already Registered!***\nRegister a new Trainer!\n=======");
                        break;
                    } else {
                        allTrainers.get(7).addTrainerToCourse(pickTrainer);
                        System.out.println("***Registration completed succesfully!***\n========");
                        trainerDoesExists8 = true;
                    }
                }
                break;
        }
    }
}
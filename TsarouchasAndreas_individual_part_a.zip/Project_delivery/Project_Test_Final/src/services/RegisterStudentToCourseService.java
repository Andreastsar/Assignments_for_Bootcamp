package services;

import models.Assignment;
import models.Course;
import models.Student;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class RegisterStudentToCourseService {

    public void registerStudentToCourse(Scanner input, List<Course> allCourses) {
        System.out.println("Pick a Course you want to register to: ");
        System.out.println("1. CB1 - Java - FullTime\n" +
                "2. CB1 - Java - PartTime" +
                "\n3. CB1 - Python - FullTime" +
                "\n4. CB1 - Python - PartTime" +
                "\n5. CB2 - Ruby - FullTime" +
                "\n6. CB2 - Ruby - PartTime" +
                "\n7. CB2 - C# - FullTime" +
                "\n8. CB2 - C# - PartTime");

        int courseChoice = input.nextInt();

        switch (courseChoice){
            case 1:     // Student chooses CB1 - Java - FullTime
                boolean studentExists1 = false;
                while (!studentExists1){
                    input.nextLine();
                    System.out.println("Enter your AMKA: ");
                    String inputAmka = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter your Name: ");
                    String inputName = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter your Surname: ");
                    String inputSurname = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter year of Birth: (integer) ");
                    int yearOfBirth = input.nextInt();
                    System.out.println("Enter month (integer): ");
                    int monthOfBirth = input.nextInt();
                    System.out.println("Enter day (integer): ");
                    int dayOfBirth = input.nextInt();
                    System.out.println("Enter tuition fees: ");
                    double inputTuition = input.nextDouble();

                    LocalDate inputDate = LocalDate.of(yearOfBirth,monthOfBirth,dayOfBirth);
                    Student inputStudent = new Student(inputName,inputSurname,inputDate,inputTuition,inputAmka);

                    if(allCourses.get(0).getStudentsPerCourse().contains(inputStudent)){
                        System.out.println("***Already Registered!***\nRegister a new Student!\n=======");
                        break;
                    }else {
                        allCourses.get(0).getStudentsPerCourse().add(inputStudent);
                        System.out.println("***Registration completed succesfully!***\n========");
                        studentExists1 = true;
                    }

                    boolean assignmentExist = false;
                    while (!assignmentExist){
                        System.out.println("Deliver an assignment for CB1 - Java - FullTime");
                        System.out.println("1. Assignment 1\n2. Assignment 2\n");
                        Assignment inputAssignment = new Assignment();
                        int assignmentOption = input.nextInt();
                        input.nextLine();
                        switch (assignmentOption){
                            case 1:
                                boolean addAnotherAssignment = false;
                                while(!addAnotherAssignment) {
                                    System.out.println("Enter year of delivery: (integer) ");
                                    int yearOfSubmit = input.nextInt();
                                    System.out.println("Enter month (integer): ");
                                    int monthOfSubmit = input.nextInt();
                                    System.out.println("Enter day (integer): ");
                                    int dayOfSubmit = input.nextInt();
                                    System.out.println("Enter oral Mark (integer 1-20)");
                                    int oralMark = input.nextInt();
                                    System.out.println("Enter total Mark (integer 1-80)");
                                    int totalMark = input.nextInt();
                                    input.nextLine();
                                    inputAssignment.setTitle("Assignment 1");
                                    inputAssignment.setDescription("Java - FullTime");
                                    inputAssignment.setOralMark(oralMark);
                                    inputAssignment.setTotalMark(totalMark);
                                    inputAssignment.setSubDateTime(LocalDate.of(yearOfSubmit, monthOfSubmit, dayOfSubmit));

                                    if (inputStudent.getStudentsAssignments().contains(inputAssignment)) {
                                        System.out.println("***Assignment already added***\n" +
                                                "Choose Another assignment");
                                        break;
                                    } else {
                                        inputStudent.getStudentsAssignments().add(inputAssignment);
                                    }
                                    System.out.println("Do you want to add another assignment to this Course?\n1.Yes\n2.No");
                                    int addAnother = input.nextInt();
                                    if(addAnother == 1){
                                        break;
                                    }else {
                                        addAnotherAssignment = true;
                                        assignmentExist = true;
                                    }
                                }
                                break;
                            case 2:
                                boolean addAnotherAssignment2 = false;
                                while(!addAnotherAssignment2) {
                                    System.out.println("Enter year of delivery: (integer) ");
                                    int yearOfSubmit2 = input.nextInt();
                                    System.out.println("Enter month (integer): ");
                                    int monthOfSubmit2 = input.nextInt();
                                    System.out.println("Enter day (integer): ");
                                    int dayOfSubmit2 = input.nextInt();
                                    System.out.println("Enter oral Mark (integer 1-20)");
                                    int oralMark2 = input.nextInt();
                                    System.out.println("Enter total Mark (integer 1-80)");
                                    int totalMark2 = input.nextInt();
                                    input.nextLine();
                                    inputAssignment.setTitle("Assignment 2");
                                    inputAssignment.setDescription("Java - FullTime");
                                    inputAssignment.setOralMark(oralMark2);
                                    inputAssignment.setTotalMark(totalMark2);
                                    inputAssignment.setSubDateTime(LocalDate.of(yearOfSubmit2, monthOfSubmit2, dayOfSubmit2));

                                    if (inputStudent.getStudentsAssignments().contains(inputAssignment)) {
                                        System.out.println("***Assignment already added***\n" +
                                                "Choose Another assignment");
                                        break;
                                    } else {
                                        inputStudent.getStudentsAssignments().add(inputAssignment);
                                    }
                                    System.out.println("Do you want to add another assignment to this Course?\n1.Yes\n2.No");
                                    int addAnother = input.nextInt();
                                    if(addAnother == 1){
                                        break;
                                    }else {
                                        addAnotherAssignment2 = true;
                                        assignmentExist = true;
                                    }
                                }
                                break;
                        }
                    }
                }
                break;
            case 2:     // Student chooses CB1 - Java - PartTime
                boolean studentExists2 = false;
                while (!studentExists2){
                    input.nextLine();
                    System.out.println("Enter your AMKA: ");
                    String inputAmka = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter your Name: ");
                    String inputName = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter your Surname: ");
                    String inputSurname = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter year of Birth: (integer) ");
                    int yearOfBirth = input.nextInt();
                    System.out.println("Enter month (integer): ");
                    int monthOfBirth = input.nextInt();
                    System.out.println("Enter day (integer): ");
                    int dayOfBirth = input.nextInt();
                    System.out.println("Enter tuition fees: ");
                    double inputTuition = input.nextDouble();

                    LocalDate inputDate = LocalDate.of(yearOfBirth,monthOfBirth,dayOfBirth);
                    Student inputStudent = new Student(inputName,inputSurname,inputDate,inputTuition,inputAmka);

                    if(allCourses.get(1).getStudentsPerCourse().contains(inputStudent)){
                        System.out.println("***Already Registered!***\nRegister a new Student!\n=======");
                        break;
                    }else {
                        allCourses.get(1).getStudentsPerCourse().add(inputStudent);
                        System.out.println("***Registration completed succesfully!***\n========");
                        studentExists2 = true;
                    }

                    boolean assignmentExist = false;
                    while (!assignmentExist){
                        System.out.println("Deliver an assignment for CB1 - Java - PartTime");
                        System.out.println("1. Assignment 1\n2. Assignment 2\n");
                        Assignment inputAssignment = new Assignment();
                        int assignmentOption = input.nextInt();
                        input.nextLine();
                        switch (assignmentOption){
                            case 1:
                                boolean addAnotherAssignment = false;
                                while(!addAnotherAssignment) {
                                    System.out.println("Enter year of delivery: (integer) ");
                                    int yearOfSubmit = input.nextInt();
                                    System.out.println("Enter month (integer): ");
                                    int monthOfSubmit = input.nextInt();
                                    System.out.println("Enter day (integer): ");
                                    int dayOfSubmit = input.nextInt();
                                    System.out.println("Enter oral Mark (integer 1-20)");
                                    int oralMark = input.nextInt();
                                    System.out.println("Enter total Mark (integer 1-80)");
                                    int totalMark = input.nextInt();
                                    input.nextLine();
                                    inputAssignment.setTitle("Assignment 1");
                                    inputAssignment.setDescription("Java - PartTime");
                                    inputAssignment.setOralMark(oralMark);
                                    inputAssignment.setTotalMark(totalMark);
                                    inputAssignment.setSubDateTime(LocalDate.of(yearOfSubmit, monthOfSubmit, dayOfSubmit));

                                    if (inputStudent.getStudentsAssignments().contains(inputAssignment)) {
                                        System.out.println("***Assignment already added***\n" +
                                                "Choose Another assignment");
                                        break;
                                    } else {
                                        inputStudent.getStudentsAssignments().add(inputAssignment);
                                    }
                                    System.out.println("Do you want to add another assignment to this Course?\n1.Yes\n2.No");
                                    int addAnother = input.nextInt();
                                    if(addAnother == 1){
                                        break;
                                    }else {
                                        addAnotherAssignment = true;
                                        assignmentExist = true;
                                    }
                                }
                                break;
                            case 2:
                                boolean addAnotherAssignment2 = false;
                                while(!addAnotherAssignment2) {
                                    System.out.println("Enter year of delivery: (integer) ");
                                    int yearOfSubmit2 = input.nextInt();
                                    System.out.println("Enter month (integer): ");
                                    int monthOfSubmit2 = input.nextInt();
                                    System.out.println("Enter day (integer): ");
                                    int dayOfSubmit2 = input.nextInt();
                                    System.out.println("Enter oral Mark (integer 1-20)");
                                    int oralMark2 = input.nextInt();
                                    System.out.println("Enter total Mark (integer 1-80)");
                                    int totalMark2 = input.nextInt();
                                    input.nextLine();
                                    inputAssignment.setTitle("Assignment 2");
                                    inputAssignment.setDescription("Java - PartTime");
                                    inputAssignment.setOralMark(oralMark2);
                                    inputAssignment.setTotalMark(totalMark2);
                                    inputAssignment.setSubDateTime(LocalDate.of(yearOfSubmit2, monthOfSubmit2, dayOfSubmit2));

                                    if (inputStudent.getStudentsAssignments().contains(inputAssignment)) {
                                        System.out.println("***Assignment already added***\n" +
                                                "Choose Another assignment");
                                        break;
                                    } else {
                                        inputStudent.getStudentsAssignments().add(inputAssignment);
                                    }
                                    System.out.println("Do you want to add another assignment to this Course?\n1.Yes\n2.No");
                                    int addAnother = input.nextInt();
                                    if(addAnother == 1){
                                        break;
                                    }else {
                                        addAnotherAssignment2 = true;
                                        assignmentExist = true;
                                    }
                                }
                                break;
                        }
                    }
                }
                break;
            case 3:     // Student chooses CB1 - Python - FullTime
                boolean studentExists3 = false;
                while (!studentExists3){
                    input.nextLine();
                    System.out.println("Enter your AMKA: ");
                    String inputAmka = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter your Name: ");
                    String inputName = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter your Surname: ");
                    String inputSurname = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter year of Birth: (integer) ");
                    int yearOfBirth = input.nextInt();
                    System.out.println("Enter month (integer): ");
                    int monthOfBirth = input.nextInt();
                    System.out.println("Enter day (integer): ");
                    int dayOfBirth = input.nextInt();
                    System.out.println("Enter tuition fees: ");
                    double inputTuition = input.nextDouble();

                    LocalDate inputDate = LocalDate.of(yearOfBirth,monthOfBirth,dayOfBirth);
                    Student inputStudent = new Student(inputName,inputSurname,inputDate,inputTuition,inputAmka);

                    if(allCourses.get(2).getStudentsPerCourse().contains(inputStudent)){
                        System.out.println("***Already Registered!***\nRegister a new Student!\n=======");
                        break;
                    }else {
                        allCourses.get(2).getStudentsPerCourse().add(inputStudent);
                        System.out.println("***Registration completed succesfully!***\n========");
                        studentExists3 = true;
                    }

                    boolean assignmentExist = false;
                    while (!assignmentExist){
                        System.out.println("Deliver an assignment for CB1 - Python - FullTime");
                        System.out.println("1. Assignment 1\n2. Assignment 2\n");
                        Assignment inputAssignment = new Assignment();
                        int assignmentOption = input.nextInt();
                        input.nextLine();
                        switch (assignmentOption){
                            case 1:
                                boolean addAnotherAssignment = false;
                                while(!addAnotherAssignment) {
                                    System.out.println("Enter year of delivery: (integer) ");
                                    int yearOfSubmit = input.nextInt();
                                    System.out.println("Enter month (integer): ");
                                    int monthOfSubmit = input.nextInt();
                                    System.out.println("Enter day (integer): ");
                                    int dayOfSubmit = input.nextInt();
                                    System.out.println("Enter oral Mark (integer 1-20)");
                                    int oralMark = input.nextInt();
                                    System.out.println("Enter total Mark (integer 1-80)");
                                    int totalMark = input.nextInt();
                                    input.nextLine();
                                    inputAssignment.setTitle("Assignment 1");
                                    inputAssignment.setDescription("Python - FullTime");
                                    inputAssignment.setOralMark(oralMark);
                                    inputAssignment.setTotalMark(totalMark);
                                    inputAssignment.setSubDateTime(LocalDate.of(yearOfSubmit, monthOfSubmit, dayOfSubmit));

                                    if (inputStudent.getStudentsAssignments().contains(inputAssignment)) {
                                        System.out.println("***Assignment already added***\n" +
                                                "Choose Another assignment");
                                        break;
                                    } else {
                                        inputStudent.getStudentsAssignments().add(inputAssignment);
                                    }
                                    System.out.println("Do you want to add another assignment to this Course?\n1.Yes\n2.No");
                                    int addAnother = input.nextInt();
                                    if(addAnother == 1){
                                        break;
                                    }else {
                                        addAnotherAssignment = true;
                                        assignmentExist = true;
                                    }
                                }
                                break;
                            case 2:
                                boolean addAnotherAssignment2 = false;
                                while(!addAnotherAssignment2) {
                                    System.out.println("Enter year of delivery: (integer) ");
                                    int yearOfSubmit2 = input.nextInt();
                                    System.out.println("Enter month (integer): ");
                                    int monthOfSubmit2 = input.nextInt();
                                    System.out.println("Enter day (integer): ");
                                    int dayOfSubmit2 = input.nextInt();
                                    System.out.println("Enter oral Mark (integer 1-20)");
                                    int oralMark2 = input.nextInt();
                                    System.out.println("Enter total Mark (integer 1-80)");
                                    int totalMark2 = input.nextInt();
                                    input.nextLine();
                                    inputAssignment.setTitle("Assignment 2");
                                    inputAssignment.setDescription("Python - FullTime");
                                    inputAssignment.setOralMark(oralMark2);
                                    inputAssignment.setTotalMark(totalMark2);
                                    inputAssignment.setSubDateTime(LocalDate.of(yearOfSubmit2, monthOfSubmit2, dayOfSubmit2));

                                    if (inputStudent.getStudentsAssignments().contains(inputAssignment)) {
                                        System.out.println("***Assignment already added***\n" +
                                                "Choose Another assignment");
                                        break;
                                    } else {
                                        inputStudent.getStudentsAssignments().add(inputAssignment);
                                    }
                                    System.out.println("Do you want to add another assignment to this Course?\n1.Yes\n2.No");
                                    int addAnother = input.nextInt();
                                    if(addAnother == 1){
                                        break;
                                    }else {
                                        addAnotherAssignment2 = true;
                                        assignmentExist = true;
                                    }
                                }
                                break;
                        }
                    }
                }
                break;
            case 4:     // Student chooses CB1 - Python - PartTime
                boolean studentExists4 = false;
                while (!studentExists4){
                    input.nextLine();
                    System.out.println("Enter your AMKA: ");
                    String inputAmka = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter your Name: ");
                    String inputName = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter your Surname: ");
                    String inputSurname = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter year of Birth: (integer) ");
                    int yearOfBirth = input.nextInt();
                    System.out.println("Enter month (integer): ");
                    int monthOfBirth = input.nextInt();
                    System.out.println("Enter day (integer): ");
                    int dayOfBirth = input.nextInt();
                    System.out.println("Enter tuition fees: ");
                    double inputTuition = input.nextDouble();

                    LocalDate inputDate = LocalDate.of(yearOfBirth,monthOfBirth,dayOfBirth);
                    Student inputStudent = new Student(inputName,inputSurname,inputDate,inputTuition,inputAmka);

                    if(allCourses.get(3).getStudentsPerCourse().contains(inputStudent)){
                        System.out.println("***Already Registered!***\nRegister a new Student!\n=======");
                        break;
                    }else {
                        allCourses.get(3).getStudentsPerCourse().add(inputStudent);
                        System.out.println("***Registration completed succesfully!***\n========");
                        studentExists4 = true;
                    }

                    boolean assignmentExist = false;
                    while (!assignmentExist){
                        System.out.println("Deliver an assignment for CB1 - Python - PartTime");
                        System.out.println("1. Assignment 1\n2. Assignment 2\n");
                        Assignment inputAssignment = new Assignment();
                        int assignmentOption = input.nextInt();
                        input.nextLine();
                        switch (assignmentOption){
                            case 1:
                                boolean addAnotherAssignment = false;
                                while(!addAnotherAssignment) {
                                    System.out.println("Enter year of delivery: (integer) ");
                                    int yearOfSubmit = input.nextInt();
                                    System.out.println("Enter month (integer): ");
                                    int monthOfSubmit = input.nextInt();
                                    System.out.println("Enter day (integer): ");
                                    int dayOfSubmit = input.nextInt();
                                    System.out.println("Enter oral Mark (integer 1-20)");
                                    int oralMark = input.nextInt();
                                    System.out.println("Enter total Mark (integer 1-80)");
                                    int totalMark = input.nextInt();
                                    input.nextLine();
                                    inputAssignment.setTitle("Assignment 1");
                                    inputAssignment.setDescription("Python - PartTime");
                                    inputAssignment.setOralMark(oralMark);
                                    inputAssignment.setTotalMark(totalMark);
                                    inputAssignment.setSubDateTime(LocalDate.of(yearOfSubmit, monthOfSubmit, dayOfSubmit));

                                    if (inputStudent.getStudentsAssignments().contains(inputAssignment)) {
                                        System.out.println("***Assignment already added***\n" +
                                                "Choose Another assignment");
                                        break;
                                    } else {
                                        inputStudent.getStudentsAssignments().add(inputAssignment);
                                    }
                                    System.out.println("Do you want to add another assignment to this Course?\n1.Yes\n2.No");
                                    int addAnother = input.nextInt();
                                    if(addAnother == 1){
                                        break;
                                    }else {
                                        addAnotherAssignment = true;
                                        assignmentExist = true;
                                    }
                                }
                                break;
                            case 2:
                                boolean addAnotherAssignment2 = false;
                                while(!addAnotherAssignment2) {
                                    System.out.println("Enter year of delivery: (integer) ");
                                    int yearOfSubmit2 = input.nextInt();
                                    System.out.println("Enter month (integer): ");
                                    int monthOfSubmit2 = input.nextInt();
                                    System.out.println("Enter day (integer): ");
                                    int dayOfSubmit2 = input.nextInt();
                                    System.out.println("Enter oral Mark (integer 1-20)");
                                    int oralMark2 = input.nextInt();
                                    System.out.println("Enter total Mark (integer 1-80)");
                                    int totalMark2 = input.nextInt();
                                    input.nextLine();
                                    inputAssignment.setTitle("Assignment 2");
                                    inputAssignment.setDescription("Python - PartTime");
                                    inputAssignment.setOralMark(oralMark2);
                                    inputAssignment.setTotalMark(totalMark2);
                                    inputAssignment.setSubDateTime(LocalDate.of(yearOfSubmit2, monthOfSubmit2, dayOfSubmit2));

                                    if (inputStudent.getStudentsAssignments().contains(inputAssignment)) {
                                        System.out.println("***Assignment already added***\n" +
                                                "Choose Another assignment");
                                        break;
                                    } else {
                                        inputStudent.getStudentsAssignments().add(inputAssignment);
                                    }
                                    System.out.println("Do you want to add another assignment to this Course?\n1.Yes\n2.No");
                                    int addAnother = input.nextInt();
                                    if(addAnother == 1){
                                        break;
                                    }else {
                                        addAnotherAssignment2 = true;
                                        assignmentExist = true;
                                    }
                                }
                                break;
                        }
                    }
                }
                break;
            case 5:     // Student chooses CB2 - Ruby - FullTime
                boolean studentExists5 = false;
                while (!studentExists5){
                    input.nextLine();
                    System.out.println("Enter your AMKA: ");
                    String inputAmka = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter your Name: ");
                    String inputName = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter your Surname: ");
                    String inputSurname = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter year of Birth: (integer) ");
                    int yearOfBirth = input.nextInt();
                    System.out.println("Enter month (integer): ");
                    int monthOfBirth = input.nextInt();
                    System.out.println("Enter day (integer): ");
                    int dayOfBirth = input.nextInt();
                    System.out.println("Enter tuition fees: ");
                    double inputTuition = input.nextDouble();

                    LocalDate inputDate = LocalDate.of(yearOfBirth,monthOfBirth,dayOfBirth);
                    Student inputStudent = new Student(inputName,inputSurname,inputDate,inputTuition,inputAmka);

                    if(allCourses.get(4).getStudentsPerCourse().contains(inputStudent)){
                        System.out.println("***Already Registered!***\nRegister a new Student!\n=======");
                        break;
                    }else {
                        allCourses.get(4).getStudentsPerCourse().add(inputStudent);
                        System.out.println("***Registration completed succesfully!***\n========");
                        studentExists5 = true;
                    }

                    boolean assignmentExist = false;
                    while (!assignmentExist){
                        System.out.println("Deliver an assignment for CB2 - Ruby - FullTime");
                        System.out.println("1. Assignment 1\n2. Assignment 2\n");
                        Assignment inputAssignment = new Assignment();
                        int assignmentOption = input.nextInt();
                        input.nextLine();
                        switch (assignmentOption){
                            case 1:
                                boolean addAnotherAssignment = false;
                                while(!addAnotherAssignment) {
                                    System.out.println("Enter year of delivery: (integer) ");
                                    int yearOfSubmit = input.nextInt();
                                    System.out.println("Enter month (integer): ");
                                    int monthOfSubmit = input.nextInt();
                                    System.out.println("Enter day (integer): ");
                                    int dayOfSubmit = input.nextInt();
                                    System.out.println("Enter oral Mark (integer 1-20)");
                                    int oralMark = input.nextInt();
                                    System.out.println("Enter total Mark (integer 1-80)");
                                    int totalMark = input.nextInt();
                                    input.nextLine();
                                    inputAssignment.setTitle("Assignment 1");
                                    inputAssignment.setDescription("Ruby - FullTime");
                                    inputAssignment.setOralMark(oralMark);
                                    inputAssignment.setTotalMark(totalMark);
                                    inputAssignment.setSubDateTime(LocalDate.of(yearOfSubmit, monthOfSubmit, dayOfSubmit));

                                    if (inputStudent.getStudentsAssignments().contains(inputAssignment)) {
                                        System.out.println("***Assignment already added***\n" +
                                                "Choose Another assignment");
                                        break;
                                    } else {
                                        inputStudent.getStudentsAssignments().add(inputAssignment);
                                    }
                                    System.out.println("Do you want to add another assignment to this Course?\n1.Yes\n2.No");
                                    int addAnother = input.nextInt();
                                    if(addAnother == 1){
                                        break;
                                    }else {
                                        addAnotherAssignment = true;
                                        assignmentExist = true;
                                    }
                                }
                                break;
                            case 2:
                                boolean addAnotherAssignment2 = false;
                                while(!addAnotherAssignment2) {
                                    System.out.println("Enter year of delivery: (integer) ");
                                    int yearOfSubmit2 = input.nextInt();
                                    System.out.println("Enter month (integer): ");
                                    int monthOfSubmit2 = input.nextInt();
                                    System.out.println("Enter day (integer): ");
                                    int dayOfSubmit2 = input.nextInt();
                                    System.out.println("Enter oral Mark (integer 1-20)");
                                    int oralMark2 = input.nextInt();
                                    System.out.println("Enter total Mark (integer 1-80)");
                                    int totalMark2 = input.nextInt();
                                    input.nextLine();
                                    inputAssignment.setTitle("Assignment 2");
                                    inputAssignment.setDescription("Ruby - FullTime");
                                    inputAssignment.setOralMark(oralMark2);
                                    inputAssignment.setTotalMark(totalMark2);
                                    inputAssignment.setSubDateTime(LocalDate.of(yearOfSubmit2, monthOfSubmit2, dayOfSubmit2));

                                    if (inputStudent.getStudentsAssignments().contains(inputAssignment)) {
                                        System.out.println("***Assignment already added***\n" +
                                                "Choose Another assignment");
                                        break;
                                    } else {
                                        inputStudent.getStudentsAssignments().add(inputAssignment);
                                    }
                                    System.out.println("Do you want to add another assignment to this Course?\n1.Yes\n2.No");
                                    int addAnother = input.nextInt();
                                    if(addAnother == 1){
                                        break;
                                    }else {
                                        addAnotherAssignment2 = true;
                                        assignmentExist = true;
                                    }
                                }
                                break;
                        }
                    }
                }
                break;
            case 6:     // Student chooses CB2 - Ruby - PartTime
                boolean studentExists6 = false;
                while (!studentExists6){
                    input.nextLine();
                    System.out.println("Enter your AMKA: ");
                    String inputAmka = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter your Name: ");
                    String inputName = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter your Surname: ");
                    String inputSurname = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter year of Birth: (integer) ");
                    int yearOfBirth = input.nextInt();
                    System.out.println("Enter month (integer): ");
                    int monthOfBirth = input.nextInt();
                    System.out.println("Enter day (integer): ");
                    int dayOfBirth = input.nextInt();
                    System.out.println("Enter tuition fees: ");
                    double inputTuition = input.nextDouble();

                    LocalDate inputDate = LocalDate.of(yearOfBirth,monthOfBirth,dayOfBirth);
                    Student inputStudent = new Student(inputName,inputSurname,inputDate,inputTuition,inputAmka);

                    if(allCourses.get(5).getStudentsPerCourse().contains(inputStudent)){
                        System.out.println("***Already Registered!***\nRegister a new Student!\n=======");
                        break;
                    }else {
                        allCourses.get(5).getStudentsPerCourse().add(inputStudent);
                        System.out.println("***Registration completed succesfully!***\n========");
                        studentExists6 = true;
                    }

                    boolean assignmentExist = false;
                    while (!assignmentExist){
                        System.out.println("Deliver an assignment for CB2 - Ruby - PartTime");
                        System.out.println("1. Assignment 1\n2. Assignment 2\n");
                        Assignment inputAssignment = new Assignment();
                        int assignmentOption = input.nextInt();
                        input.nextLine();
                        switch (assignmentOption){
                            case 1:
                                boolean addAnotherAssignment = false;
                                while(!addAnotherAssignment) {
                                    System.out.println("Enter year of delivery: (integer) ");
                                    int yearOfSubmit = input.nextInt();
                                    System.out.println("Enter month (integer): ");
                                    int monthOfSubmit = input.nextInt();
                                    System.out.println("Enter day (integer): ");
                                    int dayOfSubmit = input.nextInt();
                                    System.out.println("Enter oral Mark (integer 1-20)");
                                    int oralMark = input.nextInt();
                                    System.out.println("Enter total Mark (integer 1-80)");
                                    int totalMark = input.nextInt();
                                    input.nextLine();
                                    inputAssignment.setTitle("Assignment 1");
                                    inputAssignment.setDescription("Ruby - PartTime");
                                    inputAssignment.setOralMark(oralMark);
                                    inputAssignment.setTotalMark(totalMark);
                                    inputAssignment.setSubDateTime(LocalDate.of(yearOfSubmit, monthOfSubmit, dayOfSubmit));

                                    if (inputStudent.getStudentsAssignments().contains(inputAssignment)) {
                                        System.out.println("***Assignment already added***\n" +
                                                "Choose Another assignment");
                                        break;
                                    } else {
                                        inputStudent.getStudentsAssignments().add(inputAssignment);
                                    }
                                    System.out.println("Do you want to add another assignment to this Course?\n1.Yes\n2.No");
                                    int addAnother = input.nextInt();
                                    if(addAnother == 1){
                                        break;
                                    }else {
                                        addAnotherAssignment = true;
                                        assignmentExist = true;
                                    }
                                }
                                break;
                            case 2:
                                boolean addAnotherAssignment2 = false;
                                while(!addAnotherAssignment2) {
                                    System.out.println("Enter year of delivery: (integer) ");
                                    int yearOfSubmit2 = input.nextInt();
                                    System.out.println("Enter month (integer): ");
                                    int monthOfSubmit2 = input.nextInt();
                                    System.out.println("Enter day (integer): ");
                                    int dayOfSubmit2 = input.nextInt();
                                    System.out.println("Enter oral Mark (integer 1-20)");
                                    int oralMark2 = input.nextInt();
                                    System.out.println("Enter total Mark (integer 1-80)");
                                    int totalMark2 = input.nextInt();
                                    input.nextLine();
                                    inputAssignment.setTitle("Assignment 2");
                                    inputAssignment.setDescription("Ruby - PartTime");
                                    inputAssignment.setOralMark(oralMark2);
                                    inputAssignment.setTotalMark(totalMark2);
                                    inputAssignment.setSubDateTime(LocalDate.of(yearOfSubmit2, monthOfSubmit2, dayOfSubmit2));

                                    if (inputStudent.getStudentsAssignments().contains(inputAssignment)) {
                                        System.out.println("***Assignment already added***\n" +
                                                "Choose Another assignment");
                                        break;
                                    } else {
                                        inputStudent.getStudentsAssignments().add(inputAssignment);
                                    }
                                    System.out.println("Do you want to add another assignment to this Course?\n1.Yes\n2.No");
                                    int addAnother = input.nextInt();
                                    if(addAnother == 1){
                                        break;
                                    }else {
                                        addAnotherAssignment2 = true;
                                        assignmentExist = true;
                                    }
                                }
                                break;
                        }
                    }
                }
                break;
            case 7:     // Student chooses CB2 - C# - FullTime
                boolean studentExists7 = false;
                while (!studentExists7){
                    input.nextLine();
                    System.out.println("Enter your AMKA: ");
                    String inputAmka = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter your Name: ");
                    String inputName = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter your Surname: ");
                    String inputSurname = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter year of Birth: (integer) ");
                    int yearOfBirth = input.nextInt();
                    System.out.println("Enter month (integer): ");
                    int monthOfBirth = input.nextInt();
                    System.out.println("Enter day (integer): ");
                    int dayOfBirth = input.nextInt();
                    System.out.println("Enter tuition fees: ");
                    double inputTuition = input.nextDouble();

                    LocalDate inputDate = LocalDate.of(yearOfBirth,monthOfBirth,dayOfBirth);
                    Student inputStudent = new Student(inputName,inputSurname,inputDate,inputTuition,inputAmka);

                    if(allCourses.get(6).getStudentsPerCourse().contains(inputStudent)){
                        System.out.println("***Already Registered!***\nRegister a new Student!\n=======");
                        break;
                    }else {
                        allCourses.get(6).getStudentsPerCourse().add(inputStudent);
                        System.out.println("***Registration completed succesfully!***\n========");
                        studentExists7 = true;
                    }

                    boolean assignmentExist = false;
                    while (!assignmentExist){
                        System.out.println("Deliver an assignment for CB2 - C# - FullTime");
                        System.out.println("1. Assignment 1\n2. Assignment 2\n");
                        Assignment inputAssignment = new Assignment();
                        int assignmentOption = input.nextInt();
                        input.nextLine();
                        switch (assignmentOption){
                            case 1:
                                boolean addAnotherAssignment = false;
                                while(!addAnotherAssignment) {
                                    System.out.println("Enter year of delivery: (integer) ");
                                    int yearOfSubmit = input.nextInt();
                                    System.out.println("Enter month (integer): ");
                                    int monthOfSubmit = input.nextInt();
                                    System.out.println("Enter day (integer): ");
                                    int dayOfSubmit = input.nextInt();
                                    System.out.println("Enter oral Mark (integer 1-20)");
                                    int oralMark = input.nextInt();
                                    System.out.println("Enter total Mark (integer 1-80)");
                                    int totalMark = input.nextInt();
                                    input.nextLine();
                                    inputAssignment.setTitle("Assignment 1");
                                    inputAssignment.setDescription("C# - FullTime");
                                    inputAssignment.setOralMark(oralMark);
                                    inputAssignment.setTotalMark(totalMark);
                                    inputAssignment.setSubDateTime(LocalDate.of(yearOfSubmit, monthOfSubmit, dayOfSubmit));

                                    if (inputStudent.getStudentsAssignments().contains(inputAssignment)) {
                                        System.out.println("***Assignment already added***\n" +
                                                "Choose Another assignment");
                                        break;
                                    } else {
                                        inputStudent.getStudentsAssignments().add(inputAssignment);
                                    }
                                    System.out.println("Do you want to add another assignment to this Course?\n1.Yes\n2.No");
                                    int addAnother = input.nextInt();
                                    if(addAnother == 1){
                                        break;
                                    }else {
                                        addAnotherAssignment = true;
                                        assignmentExist = true;
                                    }
                                }
                                break;
                            case 2:
                                boolean addAnotherAssignment2 = false;
                                while(!addAnotherAssignment2) {
                                    System.out.println("Enter year of delivery: (integer) ");
                                    int yearOfSubmit2 = input.nextInt();
                                    System.out.println("Enter month (integer): ");
                                    int monthOfSubmit2 = input.nextInt();
                                    System.out.println("Enter day (integer): ");
                                    int dayOfSubmit2 = input.nextInt();
                                    System.out.println("Enter oral Mark (integer 1-20)");
                                    int oralMark2 = input.nextInt();
                                    System.out.println("Enter total Mark (integer 1-80)");
                                    int totalMark2 = input.nextInt();
                                    input.nextLine();
                                    inputAssignment.setTitle("Assignment 2");
                                    inputAssignment.setDescription("C# - FullTime");
                                    inputAssignment.setOralMark(oralMark2);
                                    inputAssignment.setTotalMark(totalMark2);
                                    inputAssignment.setSubDateTime(LocalDate.of(yearOfSubmit2, monthOfSubmit2, dayOfSubmit2));

                                    if (inputStudent.getStudentsAssignments().contains(inputAssignment)) {
                                        System.out.println("***Assignment already added***\n" +
                                                "Choose Another assignment");
                                        break;
                                    } else {
                                        inputStudent.getStudentsAssignments().add(inputAssignment);
                                    }
                                    System.out.println("Do you want to add another assignment to this Course?\n1.Yes\n2.No");
                                    int addAnother = input.nextInt();
                                    if(addAnother == 1){
                                        break;
                                    }else {
                                        addAnotherAssignment2 = true;
                                        assignmentExist = true;
                                    }
                                }
                                break;
                        }
                    }
                }
                break;
            case 8:     // Student chooses CB2 - C# - PartTime
                boolean studentExists8 = false;
                while (!studentExists8){
                    input.nextLine();
                    System.out.println("Enter your AMKA: ");
                    String inputAmka = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter your Name: ");
                    String inputName = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter your Surname: ");
                    String inputSurname = input.nextLine().trim().toUpperCase();
                    System.out.println("Enter year of Birth: (integer) ");
                    int yearOfBirth = input.nextInt();
                    System.out.println("Enter month (integer): ");
                    int monthOfBirth = input.nextInt();
                    System.out.println("Enter day (integer): ");
                    int dayOfBirth = input.nextInt();
                    System.out.println("Enter tuition fees: ");
                    double inputTuition = input.nextDouble();

                    LocalDate inputDate = LocalDate.of(yearOfBirth,monthOfBirth,dayOfBirth);
                    Student inputStudent = new Student(inputName,inputSurname,inputDate,inputTuition,inputAmka);

                    if(allCourses.get(7).getStudentsPerCourse().contains(inputStudent)){
                        System.out.println("***Already Registered!***\nRegister a new Student!\n=======");
                        break;
                    }else {
                        allCourses.get(7).getStudentsPerCourse().add(inputStudent);
                        System.out.println("***Registration completed succesfully!***\n========");
                        studentExists8 = true;
                    }

                    boolean assignmentExist = false;
                    while (!assignmentExist){
                        System.out.println("Deliver an assignment for CB2 - C# - PartTime");
                        System.out.println("1. Assignment 1\n2. Assignment 2\n");
                        Assignment inputAssignment = new Assignment();
                        int assignmentOption = input.nextInt();
                        input.nextLine();
                        switch (assignmentOption){
                            case 1:
                                boolean addAnotherAssignment = false;
                                while(!addAnotherAssignment) {
                                    System.out.println("Enter year of delivery: (integer) ");
                                    int yearOfSubmit = input.nextInt();
                                    System.out.println("Enter month (integer): ");
                                    int monthOfSubmit = input.nextInt();
                                    System.out.println("Enter day (integer): ");
                                    int dayOfSubmit = input.nextInt();
                                    System.out.println("Enter oral Mark (integer 1-20)");
                                    int oralMark = input.nextInt();
                                    System.out.println("Enter total Mark (integer 1-80)");
                                    int totalMark = input.nextInt();
                                    input.nextLine();
                                    inputAssignment.setTitle("Assignment 1");
                                    inputAssignment.setDescription("C# - PartTime");
                                    inputAssignment.setOralMark(oralMark);
                                    inputAssignment.setTotalMark(totalMark);
                                    inputAssignment.setSubDateTime(LocalDate.of(yearOfSubmit, monthOfSubmit, dayOfSubmit));

                                    if (inputStudent.getStudentsAssignments().contains(inputAssignment)) {
                                        System.out.println("***Assignment already added***\n" +
                                                "Choose Another assignment");
                                        break;
                                    } else {
                                        inputStudent.getStudentsAssignments().add(inputAssignment);
                                    }
                                    System.out.println("Do you want to add another assignment to this Course?\n1.Yes\n2.No");
                                    int addAnother = input.nextInt();
                                    if(addAnother == 1){
                                        break;
                                    }else {
                                        addAnotherAssignment = true;
                                        assignmentExist = true;
                                    }
                                }
                                break;
                            case 2:
                                boolean addAnotherAssignment2 = false;
                                while(!addAnotherAssignment2) {
                                    System.out.println("Enter year of delivery: (integer) ");
                                    int yearOfSubmit2 = input.nextInt();
                                    System.out.println("Enter month (integer): ");
                                    int monthOfSubmit2 = input.nextInt();
                                    System.out.println("Enter day (integer): ");
                                    int dayOfSubmit2 = input.nextInt();
                                    System.out.println("Enter oral Mark (integer 1-20)");
                                    int oralMark2 = input.nextInt();
                                    System.out.println("Enter total Mark (integer 1-80)");
                                    int totalMark2 = input.nextInt();
                                    input.nextLine();
                                    inputAssignment.setTitle("Assignment 2");
                                    inputAssignment.setDescription("C# - PartTime");
                                    inputAssignment.setOralMark(oralMark2);
                                    inputAssignment.setTotalMark(totalMark2);
                                    inputAssignment.setSubDateTime(LocalDate.of(yearOfSubmit2, monthOfSubmit2, dayOfSubmit2));

                                    if (inputStudent.getStudentsAssignments().contains(inputAssignment)) {
                                        System.out.println("***Assignment already added***\n" +
                                                "Choose Another assignment");
                                        break;
                                    } else {
                                        inputStudent.getStudentsAssignments().add(inputAssignment);
                                    }
                                    System.out.println("Do you want to add another assignment to this Course?\n1.Yes\n2.No");
                                    int addAnother = input.nextInt();
                                    if(addAnother == 1){
                                        break;
                                    }else {
                                        addAnotherAssignment2 = true;
                                        assignmentExist = true;
                                    }
                                }
                                break;
                        }
                    }
                }
                break;
        }
    }
}
